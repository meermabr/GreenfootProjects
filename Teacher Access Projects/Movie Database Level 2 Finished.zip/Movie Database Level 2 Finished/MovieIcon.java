
import greenfoot.*;
public class MovieIcon extends Actor
{
    private Movie movie;
    
    public MovieIcon( Movie movie )
    {
        this.movie = movie;        
        setImage( new GreenfootImage( movie.getTitle() + ".png" ) );
    }
    
    
    public void act()
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            displayDetails();
            displayRatings();
        }
    }

    public Movie getMovie()
    {
        return movie;
    }
    
    public void displayDetails()
    {
        getWorld().removeObjects( getWorld().getObjects( Detail.class ) );
        Detail d = new Detail( movie );
        getWorld().addObject( d, getX(), getY()  + 250 );
    }

    public void displayRatings()
    {
        
        getWorld().removeObjects( getWorld().getObjects( Rater.class ) );
        Rater r = new Rater( this );
        getWorld().addObject( r, getX() + 70, getY() + 190 );
    }

}
