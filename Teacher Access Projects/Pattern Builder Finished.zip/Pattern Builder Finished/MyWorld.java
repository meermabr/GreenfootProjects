import greenfoot.*;

public class MyWorld extends NoOverlapWorld
{

    private static final int WIDTH = 57;    //default is 57
    private static final int HEIGHT = 45;   //default is 45

    public MyWorld()
    {    
        // Create a new world with 20x15 cells with a cell size of 60x60 pixels.
        super(WIDTH, HEIGHT, 20);
    }

    // Removes all objects from the screen
    public void removeAll()
    {
        removeObjects( getObjects(null) );
    }

    public void allMiddle()
    {
        removeObjects( getObjects(null) );
        for ( int x = 1; x < WIDTH - 1; x++ )
        {
            for ( int y = 1; y < HEIGHT - 1; y++ )
            {
                addObject( new Wall(), x, y );
            }
        }
    }

    public void border()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x < WIDTH; x++ )
        {
            addObject( new Wall(), x, 0 );
            addObject( new Wall(), x, HEIGHT - 1 );
        }

        for ( int y = 1; y < HEIGHT - 1; y++ )
        {
            addObject( new Wall(), 0, y );
            addObject( new Wall(), WIDTH - 1, y );
        }
    }

    public void checkered()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x < WIDTH; x += 2 )
        {
            for ( int y = 0; y < HEIGHT; y += 2 )
            {
                addObject( new Wall(), x, y );
            }
        }
    } 

    public void diagonals()
    {
        removeObjects( getObjects(null) );
        int mid = Math.abs( HEIGHT - WIDTH ) / 2;

        if ( HEIGHT > WIDTH )
        {
            for ( int x = mid; x < HEIGHT + mid && x < WIDTH + mid; x++ )
            {
                addObject( new Wall(), x - mid, x);
                if ( x != HEIGHT - x - 1 )
                {
                    addObject( new Wall(), x - mid, HEIGHT - x - 1 );
                }
            }
        }
        else 
        {
            for ( int x = mid; x < HEIGHT + mid && x < WIDTH + mid; x++ )
            {
                addObject( new Wall(), x, x - mid );
                if ( x != WIDTH - x - 1 )
                {
                    addObject( new Wall(), WIDTH - x - 1, x - mid );
                }
            }
        }
    }

    public void equator()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x < WIDTH; x++ )
        {
            addObject( new Wall(), x, HEIGHT / 2 );
        }
    }

    public void fibonacci()
    {
        removeObjects( getObjects(null) );
        int previous = 1;
        int current = 1;

        for ( int y = 0; y < HEIGHT; y += 5 )
        {
            for ( int x = 0; x < previous; x++ )
            {
                addObject( new Wall(), x, y );
            }
            int next = previous + current;
            previous = current;
            current = next;            
        }

    }

    public void geometricSeries()
    {
        removeObjects( getObjects(null) );
        int current = 1;

        for ( int y = 0; y < HEIGHT; y += 5 )
        {
            for ( int x = 0; x < current; x++ )
            {
                addObject( new Wall(), x, y );
            }
            current *= 2;           
        }

    }  

    public void hemisphereLeft()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x < WIDTH / 2; x++ )
        {
            for ( int y = 0; y < HEIGHT; y++ )
            {
                addObject( new Wall(), x, y );
            }
        }
    }

    public void hemisphereRight()
    {
        removeObjects( getObjects(null) );
        for ( int x = WIDTH / 2; x < WIDTH; x++ )
        {
            for ( int y = 0; y < HEIGHT; y++ )
            {
                addObject( new Wall(), x, y );
            }
        }
    }

    public void hemisphereTop()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x < WIDTH; x++ )
        {
            for ( int y = 0; y < HEIGHT / 2; y++ )
            {
                addObject( new Wall(), x, y );
            }
        }
    }

    public void hemisphereBottom()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x < WIDTH; x++ )
        {
            for ( int y = HEIGHT / 2; y < HEIGHT; y++ )
            {
                addObject( new Wall(), x, y );
            }
        }
    }

    public void isosclesRightA()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x <= WIDTH / 2; x++ )
        {
            for ( int y = 0; y <= WIDTH / 2 - x; y++ )
            {
                addObject( new Wall(), x, y );
            }   
        }
    }

    public void isosclesRightB()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x <= WIDTH / 2; x++ )
        {
            for ( int y = 0; y <= x; y++ )
            {
                addObject( new Wall(), x, y );
            }   
        }
    }    

    public void isosclesRightC()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x <= WIDTH / 2; x++ )
        {
            for ( int y = x; y <= WIDTH / 2; y++ )
            {
                addObject( new Wall(), x, y );
            }   
        }
    }

    public void isosclesRightD()
    {
        removeObjects( getObjects(null) );
        for ( int x = 0; x <= WIDTH / 2; x++ )
        {
            for ( int y = WIDTH / 2 - x; y <= WIDTH / 2; y++ )
            {
                addObject( new Wall(), x, y );
            }   
        }
    }      

    public void jaggedSteps()
    {
        removeObjects( getObjects(null) );
        boolean left = true;
        for ( int y = 1; y < HEIGHT; y += 2 )
        {
            for ( int x = 0; x < WIDTH - 1; x++ )
            {
                if ( left ) 
                {
                    addObject( new Wall(), x, y );
                }
                else
                {
                    addObject( new Wall(), x + 1, y );
                }
            }
            left = !left;
        }        
    }

    public void act()
    {
        if ( Greenfoot.isKeyDown( "a" ) )
        {
            this.allMiddle();
        }
        if ( Greenfoot.isKeyDown( "b" ) )
        {
            this.border();
        }
        if ( Greenfoot.isKeyDown( "c" ) )
        {
            this.checkered();
        }
        if ( Greenfoot.isKeyDown( "d" ) )
        {
            this.diagonals();
        }
        if ( Greenfoot.isKeyDown( "e" ) )
        {
            this.equator();
        }
        if ( Greenfoot.isKeyDown( "f" ) )
        {
            this.fibonacci();
        }
        if ( Greenfoot.isKeyDown( "g" ) )
        {
            this.geometricSeries();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "1" ) )
        {
            this.hemisphereLeft();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "2" ) )
        {
            this.hemisphereRight();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "3" ) )
        {
            this.hemisphereTop();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "4" ) )
        {
            this.hemisphereBottom();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "1" ))
        {
            this.isosclesRightA();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "2" ))
        {
            this.isosclesRightB();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "3" ))
        {
            this.isosclesRightC();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "4" ))
        {
            this.isosclesRightD();
        }
        if ( Greenfoot.isKeyDown( "j" ) )
        {
            this.jaggedSteps();
        }
    }

}