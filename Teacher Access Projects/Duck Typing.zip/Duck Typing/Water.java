import greenfoot.*;

public class Water extends World
{
    private double duckPercent;
    
    public Water()
    {    
        super(1000, 800, 1); 
        Duck.reset();
        
        duckPercent = 0.01;
        
        for ( int x = 0; x < getWidth(); x += getWidth() / 10 )
        {
            addObject( new Gator(), x, getHeight() - 100 );
        }
    }

    public void act()
    {
        if ( Math.random() < duckPercent )
        {
            Duck rubberDucky = new Duck();
            int x = (int)(Math.random() * 901) + 50;
            addObject( rubberDucky, x, 50 );
            duckPercent += 0.0001;
        }
     
    }
}
