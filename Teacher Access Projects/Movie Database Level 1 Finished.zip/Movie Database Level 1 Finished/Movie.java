
public class Movie  
{
    private final String title;
    private final int year;
    private final String description;
    private int numVotes;
    private int totalScore;

    public Movie( String title, int year, String description, int numVotes, int totalScore )
    {
        this.title = title;
        this.year = year;
        this.description = description;
        this.numVotes = numVotes;
        this.totalScore = totalScore;
    }
    
    public Movie( String title, int year, String description )
    {
        this( title, year, description, 0,  0 );
    } 

    public void addRating( int score )
    {
        numVotes++;
        totalScore += score;
    }

    public double getRating()
    {
        return (double)totalScore / numVotes;
    }

    public String getTitle()
    {
        return title;
    }

    public int getYear()
    {
        return year;
    }

    public String getDescription()
    {
        return description;
    }

}
