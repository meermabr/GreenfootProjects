import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Back extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            MusicPlayer w = (MusicPlayer)getWorld();
            
            w.back();
        }
    } 
}
