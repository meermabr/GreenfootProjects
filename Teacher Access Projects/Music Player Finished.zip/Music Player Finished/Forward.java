import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Forward extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            MusicPlayer w = (MusicPlayer)getWorld();
            
            w.next();
        }
    }    
}
