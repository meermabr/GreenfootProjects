import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Play extends Actor
{
    private boolean playing = false;
    
    private static final String pauseImage = "pause.png";
    private static final String playImage = "play.png";

    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            changeMode();
        }
    }    

    public void changeMode()
    {        
        playing = !playing;
        
        if ( playing )
        {
            pauseMode();
        }
        else
        {
            playMode();
        }
    }
    
    public void playMode()
    {        
        MusicPlayer w = (MusicPlayer)getWorld();
        w.pause(); 
        setImage( playImage );
    }
    
    public void pauseMode()
    {
        MusicPlayer w = (MusicPlayer)getWorld();
        w.play(); 
        setImage( pauseImage );
    }
    
    public boolean isPlaying()
    {
        return playing;
    }
    
    public void stop()
    {
        playing = false;
        setImage( playImage );
    }
    
}
