import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Shuffle extends Actor
{
    private boolean shuffleOn = false;

    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            shuffleOn = !shuffleOn;

            
            if ( shuffleOn )
            {
                setImage( "random.png" );
            }
            else
            {
                setImage( "nonRandom.png" );
            } 
        }

    }    
    
    public  boolean isShuffled()
    {
        return shuffleOn;
    }
    
}
