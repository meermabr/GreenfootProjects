import greenfoot.*;

public class MusicPlayer extends World
{
    private static final int FIRST_TRACK = 0;
    private static final int FINAL_TRACK = 5;

    private int trackNumber;
    private GreenfootSound song;

    private Play playButton;
    private Shuffle shuffleButton;

    public MusicPlayer()
    {    
        super(1024, 768, 1); 
        prepare();

        trackNumber = 0;
        setSong();
        
        showText("Now playing: " + trackNumber, getWidth() / 10, getHeight () - 30);
        
    }

    public void setSong()
    {
        song = new GreenfootSound( "Song (" + trackNumber + ").mp3" );
    }

    public void next()
    {
        if ( shuffleButton.isShuffled() ) 
        {
            trackNumber = (int)(Math.random() * (FINAL_TRACK - FIRST_TRACK + 1)) + FIRST_TRACK; 
        }
        else
        {
            trackNumber++;
        }
        updateTrack();
    }    
    
    public void back()
    {
        if ( shuffleButton.isShuffled() ) 
        {
            trackNumber = (int)(Math.random() * (FINAL_TRACK - FIRST_TRACK + 1)) + FIRST_TRACK; 
        }
        else
        {
            trackNumber--;
        }
        updateTrack();    
    }

    public void updateTrack()
    {
        song.stop();
        
        if ( trackNumber > FINAL_TRACK ) 
        {
            trackNumber = FIRST_TRACK;
        }
        else if ( trackNumber < FIRST_TRACK )
        {
            trackNumber = FINAL_TRACK;
        }
        setSong();
        
        if ( playButton.isPlaying() )
        {
            song.play();
        }
        
        showText("Now playing: " + trackNumber, getWidth() / 10, getHeight () - 30);
    }

    public void play()
    {
        song.play();
    }

    public void pause()
    {
        song.pause();
    }

    public void stop()
    {
        song.stop();
        playButton.stop();
    }
    
    private void prepare()
    {
        playButton = new Play();
        shuffleButton = new Shuffle();
        addObject(new Back(),getWidth() / 5,100);
        addObject(playButton, getWidth() * 2 / 5,100);
        addObject(new Forward(),getWidth() * 3 / 5,100);
        addObject(new Stop(),getWidth() * 4 / 5,100);
        addObject(shuffleButton, getWidth() * 4 / 5, 650 );
    }
}
