import greenfoot.*; 

public class Food extends Actor
{
    public Food()
    {
        int num = (int)(Math.random() * 6 );
        setImage( "food" + num + ".png" );  
    }

    public void act() 
    {
        setLocation( getX(), getY() + 1 );
        if ( getY() > getWorld().getHeight() - 5 )
        {               
            getWorld().removeObject( this );
        }
    }    
}
