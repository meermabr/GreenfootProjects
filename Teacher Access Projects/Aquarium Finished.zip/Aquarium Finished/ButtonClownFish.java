import greenfoot.*; 

public class ButtonClownFish extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            int x = (int)(Math.random() * getWorld().getWidth() );
            int y = (int)(Math.random() * getWorld().getWidth() * 2 / 3 );
            
            getWorld().addObject( new ClownFish(), x, y );
        }
    }    
}
