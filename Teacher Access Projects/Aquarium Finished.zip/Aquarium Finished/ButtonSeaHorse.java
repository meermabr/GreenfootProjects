import greenfoot.*;

public class ButtonSeaHorse extends Actor
{    
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            int x = (int)(Math.random() * getWorld().getWidth() );
            int y = (int)(Math.random() * getWorld().getHeight() );
            
            getWorld().addObject( new SeaHorse(), x, y );
        }
    }       
}
