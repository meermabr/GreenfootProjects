import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class ClownFish extends Actor
{
    public void act() 
    {
        move( 3 );
        if ( getX() > getWorld().getWidth() - 5 )
        {
            setLocation( 0, getY() );
        }
    }    
}
