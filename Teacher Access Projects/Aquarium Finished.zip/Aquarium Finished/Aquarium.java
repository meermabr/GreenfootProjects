import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Aquarium extends World
{

    public Aquarium()
    {    
        super(1136, 935, 1); 
        
        addObject( new ButtonClownFish(), 50, 50 );
        addObject( new ButtonCrab(), 50, 80 );
        addObject( new ButtonOctopus(), 50, 110 );
        addObject( new ButtonSeaHorse(), 50, 140 );
        addObject( new ButtonStarFish(), 50, 170 );
        addObject( new ButtonTurtle(), 50, 200 );
        
        GreenfootSound music = new GreenfootSound( "waterDrops.wav" );
        //music.playLoop();
    }
    
    public void act()
    {
        if ( Math.random() < 0.05 )
        {
            Food f = new Food();
            addObject( f, (int)(Math.random() * getWidth()), 0 );
        }
    }
    
}
