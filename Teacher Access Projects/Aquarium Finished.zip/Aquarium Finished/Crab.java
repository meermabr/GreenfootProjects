import greenfoot.*;

public class Crab extends Actor
{
    private boolean goingRight;
    
    public Crab()
    {
        if ( Math.random() < 0.5 )
        {
            goingRight = true;
        }
        else
        {
            goingRight = false;
        }
    }   
    
    
    public void act() 
    {
        
        if ( goingRight )
        {
            move( 3 );
        }
        else
        {
            move( -3 );
        }
        
        if ( isAtEdge() )
        {
            goingRight = !goingRight;
        }        
    }    
}
