import greenfoot.*; 

public class ButtonTurtle extends Actor
{        
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            int x = (int)(Math.random() * getWorld().getWidth() );
            int y = (int)(Math.random() * getWorld().getHeight() );
            
            getWorld().addObject( new Turtle(), x, y );
        }
    }   
}
