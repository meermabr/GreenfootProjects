import greenfoot.*;  

public class Octopus extends SmoothMover
{
    private double velocity = 0;

    public void act() 
    {
        if ( Greenfoot.isKeyDown( "space" ) && velocity > 3)
        {
            velocity = -6;
            Greenfoot.playSound( "blop.mp3" );
        }
        else if ( getY() > getWorld().getHeight() - 150 )
        {
            velocity = -5;
        }   
        else
        {
            velocity += 0.1;

        }

        setLocation( getX(), getY() + velocity );    
    }    
}
