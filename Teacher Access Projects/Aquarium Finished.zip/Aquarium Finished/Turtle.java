import greenfoot.*; 

public class Turtle extends SmoothMover
{
    
    private double velocity;
    
    public void act() 
    {
        if ( Greenfoot.isKeyDown( "up" ) ) 
        {
            setLocation( getX(), getY() - 2 );
        }
        
        if ( Greenfoot.isKeyDown( "down" ) ) 
        {
            setLocation( getX(), getY() + 2 );        
        }
        
        if ( Greenfoot.isKeyDown( "right" ) ) 
        {
            velocity += 0.5;
        }
        
        if ( Greenfoot.isKeyDown( "left" ) ) 
        {
            velocity -= 0.5;
        }
        
        move( velocity );
        velocity *= 0.95;
        
        if ( velocity > 0 )
        {
            setImage( "turtleRight.png" );
        }
        else if ( velocity < 0 )
        {
            setImage( "turtleLeft.png" );
        }
        
        if ( isTouching( Food.class ) )
        {
            removeTouching( Food.class );
            Greenfoot.playSound( "pling.wav" );
        }
        
        
    }    
}
