import greenfoot.*;  

public class SeaHorse extends Actor
{
    private int angle;
    
    public void act() 
    {
        angle++;
        
        setRotation( angle );
        move( 2 );
        setRotation( 0 );
    }    
}
