import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class ButtonStarFish extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            int x = (int)(Math.random() * getWorld().getWidth() );
            int y = (int)(Math.random() * getWorld().getHeight() );
            
            StarFish star = new StarFish();
            getWorld().addObject( star, x, y );
            star.setRotation( (int)(Math.random() * 360 ));
        }
    }   
}
