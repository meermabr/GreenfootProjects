import greenfoot.*;  
public class ButtonCrab extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            int x = (int)(Math.random() * getWorld().getWidth() );
            int y = (int)(Math.random() * 150 ) + getWorld().getHeight() - 150;
            
            getWorld().addObject( new Crab(), x, y );
        }
    }     
}
