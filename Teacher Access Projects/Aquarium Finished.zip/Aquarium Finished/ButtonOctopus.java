import greenfoot.*; 

public class ButtonOctopus extends Actor
{
        public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            int x = (int)(Math.random() * getWorld().getWidth() );
            int y = 100;
            
            getWorld().addObject( new Octopus(), x, y );
        }
    }   
}
