import greenfoot.*;

public class MyWorld extends ArrayWallWorld
{
    private static final int DEFAULT_ROWS = 45;
    private static final int DEFAULT_COLS = 57;

    public MyWorld()
    {    
        super(DEFAULT_ROWS, DEFAULT_COLS );
    }

    public MyWorld( int numRows, int numCols )
    {
        super( numRows, numCols );
    }

    public void allMiddle()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 1; r < walls.length - 1; r++ )
        {
            for ( int c = 1; c < walls[r].length - 1; c++ )
            {
                walls[r][c] = true;
            }
        }
        draw2D( walls );
    }

    public void border()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int c = 0; c < walls[0].length; c++ )
        {
            walls[0][c] = true;
            walls[walls.length - 1][c] = true;
        }

        for ( int r = 1; r < walls.length - 1; r++ )
        {
            walls[r][0] = true;
            walls[r][walls[r].length - 1] = true;
        }

        draw2D( walls );
    }

    public void checkered()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 0; r < walls.length; r += 2 )
        {
            for ( int c = 0; c < walls[r].length; c += 2 )
            {
                walls[r][c] = true;
            }
        }

        draw2D( walls );
    } 

    public void diagonals()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        int midRow = walls.length / 2;
        int midCol = walls[0].length / 2;

        int n = Math.min( midRow, midCol );
        if ( Math.min( walls.length, walls[0].length) % 2 == 0 )
        {
            n--;
        }
        while( n >= 0 )
        {
            walls[midRow - n][midCol - n] = true;
            walls[midRow + n][midCol - n] = true;
            walls[midRow - n][midCol + n] = true;
            walls[midRow + n][midCol + n] = true;
            n--;
        }

        draw2D( walls );
    }

    public void exterior()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        int midRow = walls.length / 2;
        int midCol = walls[0].length / 2;

        int radius = Math.min( midRow, midCol );

        for ( int r = 0; r < walls.length; r++ )
        {
            for ( int c = 0; c < walls[r].length; c++ )
            {
                int dr = r - midRow;
                int dc = c - midCol;
                int dist = (int)Math.sqrt( dr * dr + dc * dc );
                if ( dist > radius )
                {
                    walls[r][c] = true;
                }
            }
        }

        draw2D( walls );
    }

    public void fibonacci()
    {
        int previous = 1;
        int current = 1;

        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 0; r < walls.length; r += 5 )
        {
            for ( int c = 0; c < previous && c < walls[r].length; c++ )
            {
                walls[r][c] = true;
            }
            int next = previous + current;
            previous = current;
            current = next;            
        }

        draw2D( walls );
    }

    public void geometricSeries()
    {
        int current = 1;
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 0; r < walls.length; r += 5 )
        {
            for ( int c = 0; c < current && c < walls[r].length; c++ )
            {
                walls[r][c] = true;
            }
            current *= 2;      
        }

        draw2D( walls );
    }  

    public void hemisphereLeft()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 0; r < walls.length; r++ )
        {
            for ( int c = 0; c < walls[r].length / 2; c++ )
            {
                walls[r][c] = true;
            }
        }

        draw2D( walls );
    }

    public void hemisphereRight()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 0; r < walls.length; r++ )
        {
            for ( int c = walls[r].length / 2; c < walls[r].length; c++ )
            {
                walls[r][c] = true;
            }
        }

        draw2D( walls );
    }

    public void hemisphereTop()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int c = 0; c < walls[0].length; c++ )
        {
            for ( int r = 0; r < walls.length / 2; r++ )
            {
                walls[r][c] = true;
            }
        }

        draw2D( walls );
    }

    public void hemisphereBottom()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int c = 0; c < walls[0].length; c++ )
        {
            for ( int r = walls.length / 2; r < walls.length; r++ )
            {
                walls[r][c] = true;
            }
        }

        draw2D( walls );    
    }

    public void isosclesRightA()
    {        
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];
        int len = Math.min( walls.length, walls[0].length ) - 1;

        int shiftRight = Math.max( 0, walls[0].length - len) / 2;
        int shiftDown = Math.max( 0, walls.length - len) / 2;

        for ( int r = 0; r <= len; r++ )
        {
            for ( int c = 0; c <= len - r; c++ )
            {
                walls[r + shiftDown][c + shiftRight] = true;
            }
        }

        draw2D( walls );    
    }

    public void isosclesRightB()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];
        int len = Math.min( walls.length, walls[0].length ) - 1;

        int shiftRight = Math.max( 0, walls[0].length - len) / 2;
        int shiftDown = Math.max( 0, walls.length - len) / 2;

        for ( int r = 0; r <= len; r++ )
        {
            for ( int c = 0; c <= r; c++ )
            {
                walls[r + shiftDown][c + shiftRight] = true;
            }
        }

        draw2D( walls );  
    }    

    public void isosclesRightC()
    {        
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];
        int len = Math.min( walls.length, walls[0].length ) - 1;

        int shiftRight = Math.max( 0, walls[0].length - len) / 2;
        int shiftDown = Math.max( 0, walls.length - len) / 2;

        for ( int r = 0; r <= len; r++ )
        {
            for ( int c = r; c <= len; c++ )
            {
                walls[r + shiftDown][c + shiftRight] = true;
            }
        }

        draw2D( walls );
    }

    public void isosclesRightD()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];
        int len = Math.min( walls.length, walls[0].length ) - 1;

        int shiftRight = Math.max( 0, walls[0].length - len) / 2;
        int shiftDown = Math.max( 0, walls.length - len) / 2;

        for ( int r = 0; r <= len; r++ )
        {
            for ( int c = len - r; c <= len; c++ )
            {
                walls[r + shiftDown][c + shiftRight] = true;
            }
        }

        draw2D( walls );
    }      

    public void jaggedSteps()
    {
        boolean left = true;
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 0; r < walls.length; r += 2 )
        {
            for ( int c = 1; c < walls[r].length; c++ )
            {
                if ( left )
                {
                    walls[r][c -1] = true;
                }
                else
                {
                    walls[r][c] = true;
                }
            }
            left = !left;
        }

        draw2D( walls );
    }

    public void knitting()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int c = 1; c < walls[0].length; c += 3 )
        {
            for ( int r = c % 2 == 0 ? 0 : 3; r < walls.length; r += 6 )
            {
                walls[r][c] = true;
                if ( r + 1 < walls.length )
                {
                    walls[r+1][c] = true;    
                }
                if ( r + 2 < walls.length )
                {
                    walls[r+2][c] = true;
                }
            }
        }
        for ( int r = 1; r < walls.length; r += 3 )
        {
            for ( int c = r % 2 == 1 ? 0 : 3; c < walls[r].length; c += 6 )
            {
                walls[r][c] = true;
                if ( c + 1 < walls[r].length )
                {
                    walls[r][c+1] = true;
                }
                if ( c + 2 < walls[r].length )
                {
                    walls[r][c+2] = true;
                }
            }
        }

        draw2D( walls );
    }

    public void longitudes()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int c = 1; c < walls[0].length; c += 3 )
        {
            for ( int r = 0; r < walls.length; r++ )
            {
                walls[ r ][c] = true;
            }
        }

        draw2D( walls );
    }

    public void latitudes()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 1; r < walls.length; r += 3 )
        {
            for ( int c = 0; c < walls[0].length; c++ )
            {
                walls[ r ][c] = true;
            }
        }

        draw2D( walls );
    }

    public void act()
    {
        if ( Greenfoot.isKeyDown( "a" ) )
        {
            this.allMiddle();
        }
        if ( Greenfoot.isKeyDown( "b" ) )
        {
            this.border();
        }
        if ( Greenfoot.isKeyDown( "c" ) )
        {
            this.checkered();
        }
        if ( Greenfoot.isKeyDown( "d" ) )
        {
            this.diagonals();
        }
        if ( Greenfoot.isKeyDown( "e" ) )
        {
            this.exterior();
        }
        if ( Greenfoot.isKeyDown( "f" ) )
        {
            this.fibonacci();
        }
        if ( Greenfoot.isKeyDown( "g" ) )
        {
            this.geometricSeries();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "1" ) )
        {
            this.hemisphereLeft();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "2" ) )
        {
            this.hemisphereRight();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "3" ) )
        {
            this.hemisphereTop();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "4" ) )
        {
            this.hemisphereBottom();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "1" ))
        {
            this.isosclesRightA();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "2" ))
        {
            this.isosclesRightB();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "3" ))
        {
            this.isosclesRightC();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "4" ))
        {
            this.isosclesRightD();
        }
        if ( Greenfoot.isKeyDown( "j" ) )
        {
            this.jaggedSteps();
        }
        if ( Greenfoot.isKeyDown( "k" ) )
        {
            this.knitting();
        }
        if ( Greenfoot.isKeyDown( "l" ) && Greenfoot.isKeyDown( "1" ))
        {
            this.latitudes();
        }
        if ( Greenfoot.isKeyDown( "l" ) && Greenfoot.isKeyDown( "2" ))
        {
            this.longitudes();
        }
        if ( Greenfoot.isKeyDown( "F1" ) )
        {
            MyWorld w = new MyWorld(DEFAULT_ROWS, DEFAULT_COLS);
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F2" ) )
        {
            MyWorld w = new MyWorld( DEFAULT_COLS, DEFAULT_ROWS );
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F3" ) )
        {
            MyWorld w = new MyWorld( DEFAULT_ROWS / 2, DEFAULT_COLS / 2 );
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F4" ) )
        {
            MyWorld w = new MyWorld( DEFAULT_COLS / 2, DEFAULT_ROWS / 2 );
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F5" ) )
        {
            int randRow = (int)(Math.random() * 50 ) + 10;
            int randCol = (int)(Math.random() * 50 ) + 10;

            MyWorld w = new MyWorld( randRow / 2, randCol / 2 );
            Greenfoot.setWorld( w );
        }
    }
}