import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Seed extends Actor
{
    private Flower flower;
    private int timeToBloom;

    public Seed()
    {
        timeToBloom = 500;
        flower = new Flower();
    }

    public void act() 
    {
        timeToBloom--;
        
        if ( timeToBloom == 0 )
        {
            setImage( flower.getImage() );
        }

        if ( timeToBloom <= 0 )
        {

            getImage().setTransparency( Math.abs( timeToBloom ) );
        }

        if ( timeToBloom <= -255 )
        {
            getWorld().addObject( flower, getX(), getY() );
            getWorld().removeObject( this );

        }
    }    
}
