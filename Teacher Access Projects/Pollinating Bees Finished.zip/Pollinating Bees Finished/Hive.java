import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class Hive extends Actor
{
    private List<Bee> bees;
    private boolean firstAct;
    private String comeHomeButton;
    
    public Hive( int numBees, String key )
    {
        comeHomeButton = key;
        
        firstAct = true;
        buildBees( numBees );
    }

    public void act() 
    {

        if ( firstAct )
        {
            addBeesToWorld();
            firstAct = false;
        }

        if ( Greenfoot.isKeyDown( comeHomeButton ) )
        {
            callBeesBack();
        }

    }
    
    public void buildBees( int numBees )
    {
        bees = new ArrayList<Bee>();
        for ( int i = 0; i < numBees; i++ )
        {
            bees.add( new Bee() );
        }
    }

    public void addBeesToWorld()
    {
        for ( Bee b : bees )
        {
            getWorld().addObject( b, getX(), getY() );
        }
    }

    public void callBeesBack()
    {

        for ( Bee b : bees )
        {
            b.turnTowards( getX(), getY() );
        }
    }

}    

