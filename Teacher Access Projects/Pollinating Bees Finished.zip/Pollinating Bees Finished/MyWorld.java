import greenfoot.*; 

public class MyWorld extends World
{
    private static final int FLOWER_Y_RANGE = 500;
    private static final int FLOWER_Y_START = 436;
    
    private static final int HIVE_Y_RANGE = 200;
    private static final int HIVE_Y_START = 300;
    
    private static final int BEES_PER_RANGE = 10;
    private static final int BEES_PER_MINIMUM = 5;
    
    
    public MyWorld()
    {   
        super(1136, 936, 1); 
        buildFlowers( 5 );
        buildHives(2);
        
        setPaintOrder( Hive.class, Bee.class, Flower.class, Seed.class );
    }

    public void buildFlowers(int amount)
    {
        for ( int i = 0; i < amount; i++ )
        {
            int x = (int)(Math.random() * getWidth() );
            int y = (int)(Math.random() * FLOWER_Y_RANGE) + FLOWER_Y_START ;
            addObject( new Flower(), x, y );
        }
    }
    
    public void buildHives(int amount)
    {
        for ( int i = 1; i <= amount; i++ )
        {
            int x = (int)(Math.random() * getWidth() );
            int y = (int)(Math.random() * HIVE_Y_RANGE) + HIVE_Y_START;

            int numBees = (int)(Math.random() * BEES_PER_RANGE ) + BEES_PER_MINIMUM;
            
            addObject( new Hive( numBees, "" + i ), x, y );
        }
    }
}
