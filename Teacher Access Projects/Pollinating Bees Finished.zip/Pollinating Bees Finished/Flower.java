import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Flower extends Actor
{
    private static final int NUMBER_FLOWER_IMAGES = 12;
    private static final int TIMER_BEGIN = 800;
    private static final int DISTANCE_TO_BEE = 2;
    
    private int timer = TIMER_BEGIN;
    
    public Flower()
    {
        int randNum = (int)(Math.random()*NUMBER_FLOWER_IMAGES)+1;
        setImage( "flower" + randNum + ".png" );
    }
    
    public void act() 
    {
        timer--;
        
        if ( !getObjectsInRange(DISTANCE_TO_BEE, Bee.class ).isEmpty() )
        {
            timer = TIMER_BEGIN;
        }
        
        getImage().setTransparency( Math.min( 255, timer) );
        
        
        if ( timer <= 0 )
        {
            getWorld().removeObject( this );
        }   
    }    
}
