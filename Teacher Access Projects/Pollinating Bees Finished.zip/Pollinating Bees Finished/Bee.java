import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class Bee extends Actor
{
    private static final int DEGREES = 45;
    private static final int SPEED = 2;
    private static final int RANGE = 200;
    private static final int FLOWER_TIME = 300;
    private static final int ROAM_TIME = 200;
    private static final int POLLEN_MAX = 300;

    private int timer = 0;
    private int collectedPollen = 0;

    public void Bee()
    {
        setRotation( (int)(Math.random() * 360) );
    }

    public void act() 
    {
        timer--;

        if ( timer > ROAM_TIME )
        {
            collectedPollen++;
            return;
        }

        if ( timer > 0 )
        {
            setImage( "bee3.png" );
        }

        roam();

        if ( timer < 0 )
        {
            if ( collectedPollen >= POLLEN_MAX && getObjectsInRange( RANGE / 2, Flower.class ).isEmpty() )
            {
                collectedPollen = 0;
                getWorld().addObject( new Seed(), getX(), getY() );
                timer = ROAM_TIME;
            }

            targetFlower();
        }

    }
    public void targetFlower()
    {

        setImage( "bee.png" );
        Flower f = findNearestFlower();

        if ( f != null )
        {
            moveToFlower( f );
        }

    }

    public void moveToFlower( Flower f )
    {
        turnTowards( f.getX(), f.getY() );
        if ( distanceTo( f ) <= SPEED  )
        {
            timer = FLOWER_TIME;
            setImage( "bee2.png" );

            if ( getObjectsInRange(SPEED, Bee.class ).size() > SPEED )
            {
                timer = ROAM_TIME;
            }

        }

    }

    public void roam()
    {
        turn( (int)(Math.random() * (DEGREES * 2 +1)) - DEGREES); 
        move( SPEED );
    }

    public double distanceTo( Flower f )
    {
        int dx = f.getX() - getX();
        int dy = f.getY() - getY();
        return Math.sqrt( dx * dx + dy * dy );
    }

    public Flower findNearestFlower()
    {
        List<Flower> flowers = getObjectsInRange( RANGE, Flower.class );

        if ( flowers.isEmpty() )
        {
            return null;
        }

        double smallestDistance = Double.MAX_VALUE;
        Flower closest = null;
        for ( Flower f : flowers )
        {
            double distance = distanceTo( f );

            if ( distance < smallestDistance )
            {
                closest = f;
                smallestDistance = distance;
            }

        }

        return closest;
    }
}
