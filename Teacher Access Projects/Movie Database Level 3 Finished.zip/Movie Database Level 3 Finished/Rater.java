import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Rater extends Actor
{
    private MovieIcon movieIcon;

    public Rater( MovieIcon movieIcon )
    {
        this.movieIcon = movieIcon;
    }    

    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) ) 
        {
            int value = Integer.parseInt(Greenfoot.ask("On a scale from 1-10, how would you rate " + movieIcon.getMovie().getTitle() + "?"));

            if ( value > 0 && value <= 10 )
            {
                movieIcon.getMovie().addRating(value);
                movieIcon.displayDetails();
            }

            getWorld().removeObject( this );
        }
    }    
}
