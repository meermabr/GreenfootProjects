import java.util.*;

public class MovieCollection  
{
    private List<Movie> movies;

    public MovieCollection()
    {
        movies = new ArrayList<Movie>();
    }

    public void addMovie(Movie m)
    {
        movies.add( m );
    }
    
    public void removeMovie( Movie m )
    {
        movies.remove( m );
    }
    
    public Movie[] getMovieSubset( int number, int startIndex )
    {
        Movie[] temp = new Movie[ Math.min( number, size() )];
        
        for ( int i = 0; i < temp.length; i++ )
        {
            temp[i] = movies.get( ( i + startIndex ) % movies.size() );
        }
        
        return temp;
        
    }
    
    public int size()
    {
        return movies.size();
    }
}