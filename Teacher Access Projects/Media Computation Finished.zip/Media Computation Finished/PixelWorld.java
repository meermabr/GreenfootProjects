import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Allows images to be converted with 2d Arrays of Colors instead of GreenfootImages.
 * 
 * @author Meermans
 */
public class PixelWorld extends World
{
    public PixelWorld(int worldWidth, int worldHeight, int cellSize)
    {   
        super( worldWidth, worldHeight, cellSize );
    }
    
    /**
     * Get the current image as a 2D array of Colors.
     * @return  A 2D, Row-Col array of Colors based on the current background.
     */    
    protected Color[][] getPixels()
    {
        return getPixels( getBackground() );
    }

    /**
     * Get the sent image as a 2D array of Colors.
     * @param   The GreenfootImage which will be used to create the 2D Color array.
     * @return  A 2D, Row-Col array of Colors based on the image inputted.
     */    
    protected Color[][] getPixels(GreenfootImage img)
    {
        GreenfootImage bg = getBackground();
        Color [][] pixels = new Color[ img.getHeight() ][ img.getWidth() ];

        for ( int y = 0; y < img.getHeight(); y++ )
        {
            for ( int x = 0; x < img.getWidth(); x++ )
            {
                pixels[y][x] = img.getColorAt( x, y );
            }
        }
        return pixels;
    }
    
    
    /**
     * Draw the given 2D array into the background, given array must be the same size as original picture.
     * @param pixels The 2D array of pixels to be drawn.
     */
    protected void setBackground( Color [][] pixels )
    {
        GreenfootImage img = new GreenfootImage( pixels[0].length, pixels.length );
        for ( int row = 0; row < pixels.length; row++ )
        {
            for ( int col = 0; col < pixels[row].length; col++ )
            {
                img.setColorAt( col, row, pixels[row][col] );
            }
        }

        setBackground( img );
    }
    
}
