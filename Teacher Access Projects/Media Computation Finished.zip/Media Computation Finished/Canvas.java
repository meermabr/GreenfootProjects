import greenfoot.*;

/**
 * A class which stores a background image and provides methods which may modify it.
 */
public class Canvas extends PixelWorld
{
    //Feel free to change the images!
    private static String alternate = "Birds on a Line.png";
    private static String filename = "City Dancer.png";

    private static final GreenfootImage original = new GreenfootImage( filename );

    /**
     * Constructor for objects of class Canvas, sets background to the default original picture.
     */
    public Canvas()
    {    
        super( original.getWidth(), original.getHeight(), 1 );
        reset();
        showText("Type a letter from a to z, the numbers 1 or 2, space, or enter for different effects", getWidth()/2, 30);
        
    }

    /**
     * Draw the original file back onto the background.
     */
    public void reset()
    {
        setBackground( filename );
    }

    /**
     * Purely a demonstration of doing some odd math on colors.
     * This keeps the old red of each pixel while using a 0-255 for
     * both green and blue based on the current row / column of a pixel.
     */
    public void weirdGradientDemo()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][c] = new Color(  current.getRed(), r % 256, c % 256 );
            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen turns into a randomly generated Color.
     */
    public void randomizeAllPixels()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                int red = (int)(Math.random() * 256 );
                int green = (int)(Math.random() * 256 );
                int blue = (int)(Math.random() * 256 );
                pixels[r][c] = new Color( red, green, blue );
            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen turns into the same randomly generated Color.
     */
    public void randomizeSolid()
    {
        Color [][] pixels = getPixels();

        int red = (int)(Math.random() * 256 );
        int green = (int)(Math.random() * 256 );
        int blue = (int)(Math.random() * 256 );

        Color solid = new Color( red, green, blue );

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                pixels[r][c] = solid;
            }
        }

        setBackground( pixels );
    }

    /**
     * Every row on the screen gets one solid randomized color.
     */
    public void randomizeRows()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            int red = (int)(Math.random() * 256 );
            int green = (int)(Math.random() * 256 );
            int blue = (int)(Math.random() * 256 );

            Color solid = new Color( red, green, blue );

            for ( int c = 0; c < pixels[r].length; c++ )
            {
                pixels[r][c] = solid;
            }
        }

        setBackground( pixels );
    }

    /**
     * Every column on the screen gets one solid randomized color.
     */
    public void randomizeColumns()
    {
        Color [][] pixels = getPixels();

        for ( int c = 0; c < pixels[0].length; c++ )
        {

            int red = (int)(Math.random() * 256 );
            int green = (int)(Math.random() * 256 );
            int blue = (int)(Math.random() * 256 );

            Color solid = new Color( red, green, blue );

            for ( int r = 0; r < pixels.length; r++ )
            {
                pixels[r][c] = solid;
            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen becomes slightly brighter than it was before.
     */
    public void brighter()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][c] = current.brighter();
            }
        }

        setBackground( pixels );
    }  

    /**
     * Every pixel on the screen becomes slightly darker than it was before.
     */
    public void darker()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][c] = current.darker();
            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen becomes the inverted color of what it was before.
     * Example: (0,0,0) becomes (255,255,255)
     * Example: (1,100, 50) becomes ( 254, 155, 205)
     */
    public void invert()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int red = 255 - current.getRed();
                int green = 255 - current.getGreen();
                int blue = 255 - current.getBlue();

                pixels[r][c] = new Color( red, green, blue );

            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old green and blue value but gets
     * an inverted amount of red value.
     * Example: (50, 30, 70) becomes (205, 30, 70)
     */
    public void invertRed()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int red = 255 - current.getRed();

                pixels[r][c] = new Color( red, current.getGreen(), current.getBlue() );

            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old red and blue value but gets
     * an inverted amount of green value.
     * Example: (50, 30, 70) becomes (50, 225, 70)
     */
    public void invertGreen()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int green = 255 - current.getGreen();

                pixels[r][c] = new Color( current.getRed(), green, current.getBlue() );

            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old red and green value but gets
     * an inverted amount of blue value.
     * Example: (50, 30, 70) becomes (50, 30, 185)
     */
    public void invertBlue()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int blue = 255 - current.getBlue();

                pixels[r][c] = new Color( current.getRed(), current.getGreen(), blue );

            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen becomes the closest gray equivalent pixel.
     * A gray value is the average of the old red, green, and blue values,
     * then replace the red, green, and blue values all with the calculated gray value.
     */
    public void grayScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int red = current.getRed();
                int green = current.getGreen();
                int blue = current.getBlue();

                int ave = (int)Math.round( ( red + green + blue ) / 3.0 );
                pixels[r][c] = new Color( ave, ave, ave );

            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old red and loses all of its green and blue.
     * Example: (50, 30, 70) becomes (50, 0, 0)
     */
    public void redScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                pixels[r][c] = new Color( pixels[r][c].getRed(), 0, 0 );                
            }
        }

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its original red value, but changes
     * the green and blue value to the average of the red, green, and blue values.
     */
    public void redGrayScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int red = current.getRed();
                int green = current.getGreen();
                int blue = current.getBlue();

                int ave = (int)Math.round( ( red + green + blue ) / 3.0 );
                pixels[r][c] = new Color( red, ave, ave );

            }
        }

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its old red and loses all of its green and blue.
     * Example: (50, 30, 70) becomes (0, 30, 0)
     */
    public void greenScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                pixels[r][c] = new Color( 0, pixels[r][c].getGreen(), 0 );                
            }
        }

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its original green value, but changes
     * the red and blue value to the average of the red, green, and blue values.
     */
    public void greenGrayScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int red = current.getRed();
                int green = current.getGreen();
                int blue = current.getBlue();

                int ave = (int)Math.round( ( red + green + blue ) / 3.0 );
                pixels[r][c] = new Color( ave, green, ave );

            }
        }

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its old red and loses all of its green and blue.
     * Example: (50, 30, 70) becomes (0, 0, 70)
     */
    public void blueScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                pixels[r][c] = new Color( 0, 0, pixels[r][c].getBlue() );                
            }
        }

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its original blue value, but changes
     * the red and green value to the average of the red, green, and blue values.
     */
    public void blueGrayScale()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                int red = current.getRed();
                int green = current.getGreen();
                int blue = current.getBlue();

                int ave = (int)Math.round( ( red + green + blue ) / 3.0 );
                pixels[r][c] = new Color( ave, ave, blue );

            }
        }

        setBackground( pixels );

    }

    /**
     * The top half of the picture is duplicated, upside down, on the bottom of the picture.
     * The entire row 0 is thus placed in the final row.
     */
    public void mirrorTopToBottom()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length / 2; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[pixels.length - r - 1][c] = current;
            }
        }

        setBackground( pixels );

    } 

    /**
     * The bottom half of the picture is duplicated, upside down, on the top of the picture.
     * The entire final row is thus placed in the first row.
     */
    public void mirrorBottomToTop()
    {
        Color [][] pixels = getPixels();

        for ( int r = pixels.length / 2; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[pixels.length - r - 1][c] = current;
            }
        }

        setBackground( pixels );

    }  

    /**
     * The left half of the picture is duplicated, in reverse, on the right half of the picture.
     * The entire column 0 is thus placed in the final column.
     */
    public void mirrorLeftToRight()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length / 2; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][pixels[r].length - c - 1] = current;
            }
        }

        setBackground( pixels );

    }    

    /**
     * The right half of the picture is duplicated, in reverse, on the left half of the picture.
     * The entire final column is thus placed in the first column.
     */
    public void mirrorRightToLeft()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = pixels[r].length / 2; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][pixels[r].length - c - 1] = current;
            }
        }

        setBackground( pixels );

    }  

    /**
     * The entire image is flipped, with column 0 and the final column swapping locations.
     */
    public void flipHorizontal()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = pixels[r].length / 2; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][c] = pixels[r][pixels[r].length - c - 1];
                pixels[r][pixels[r].length - c - 1] = current;
            }
        }

        setBackground( pixels );

    }

    /**
     * The entire image is flipped, with row 0 and the final row swapping locations.
     */
    public void flipVertical()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length / 2; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][c] = pixels[pixels.length - r - 1][c];
                pixels[pixels.length - r - 1][c] = current;
            }
        }

        setBackground( pixels );

    }

    /**
     * Compares every pair of pixels (a left pixel to a right) and determines
     * if the 'distance' between the two pairs of pixels is smaller than
     * the given threshold. If so, the pixel is set to white, if not the left
     * pixel is set to black.
     */
    public void detectEdges(int threshold)
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length - 1; r++ )
        {
            for ( int c = 0; c < pixels[r].length - 1; c++ )
            {
                Color current = pixels[r][c];
                Color rightColor = pixels[r][c + 1];

                double distance = colorDistance( current, rightColor );

                if ( distance < threshold )
                {
                    pixels[r][c] = Color.WHITE;
                }    
                else
                {
                    pixels[r][c] = Color.BLACK;
                }
            }
        }

        // The final column is untouched above. Set it to the same value as the second
        // to last column.
        int finalColumn = pixels[0].length - 1;
        for ( int r = 0; r < pixels.length - 1; r++ )
        {
            pixels[r][finalColumn] = pixels[r][finalColumn - 1];
        }

        setBackground( pixels );

    }    

    /**
     * Helper method which determines the 3-dimensional distance two colors
     * would be on a color cube.
     */
    private double colorDistance( Color a, Color b )
    {
        int dRed = a.getRed() - b.getRed();
        int dGreen = a.getGreen() - b.getGreen();
        int dBlue = a.getBlue() - b.getBlue();

        return Math.sqrt( dRed * dRed + dGreen * dGreen + dBlue * dBlue );
    }    

    /**
     * Challenge: Given a 'strength', average the blocks of pixels of radius 'strength'
     * and make each pixel in the box equal the same value.
     */
    public void pixelate( int strength )
    {
        Color [][] pixels = getPixels();

        for ( int r = strength; r < pixels.length + strength; r += 2 * strength )
        {
            for ( int c = strength; c < pixels[r].length + strength; c += 2 * strength )
            {
                int red = 0, green = 0, blue = 0, pixelsInBox = 0;

                for ( int boxR = r - strength; boxR < r + strength && boxR < pixels.length; boxR++ )
                {
                    for ( int boxC = c - strength; boxC < c + strength && boxC < pixels[r].length; boxC++ )
                    {
                        Color current = pixels[boxR][boxC];
                        red += current.getRed();
                        green += current.getGreen();
                        blue += current.getBlue();
                        pixelsInBox++;
                    }
                }

                Color average = new Color ( red / pixelsInBox, green / pixelsInBox, blue / pixelsInBox );

                for ( int boxR = r - strength; boxR < r + strength && boxR < pixels.length; boxR++ )
                {
                    for ( int boxC = c - strength; boxC < c + strength && boxC < pixels[r].length; boxC++ )
                    {
                        pixels[boxR][boxC] = average;
                    }
                }

            }
        }

        setBackground( pixels );

    }    

    /**
     * Hides the alternate imagefile defined in the fields.
     */
    public void hideImage()
    {
        hideImage( alternate );
    }

    /**
     * Hides a second image into the current background.
     * @param A filename which has a picture with the same size as the current background.
     */
    public void hideImage( String fileToHide )
    {
        Color [][] pixels = getPixels();

        GreenfootImage img = new GreenfootImage( fileToHide );
        Color [][] pixels2 = getPixels( img );

        for ( int r = 0; r < pixels.length - 1; r++ )
        {
            for ( int c = 0; c < pixels[r].length - 1; c++ )
            {
                Color current = pixels[r][c];
                Color current2 = pixels2[r][c];

                int redHide = hideBits( current.getRed(), current2.getRed() );
                int greenHide = hideBits( current.getGreen(), current2.getGreen() );
                int blueHide = hideBits( current.getBlue(), current2.getBlue() );

                pixels[r][c] = new Color( redHide, greenHide, blueHide );
            }
        }

        setBackground( pixels );

    }

    /**
     * Flips each bit for the red/green/blue values.
     * If the red value is written ABCD EFGH in binary, then the flipped
     * red would be EFGH ABCD.
     */
    public void bitExchange()
    {        
        Color [][] pixels = getPixels();        

        for ( int r = 0; r < pixels.length - 1; r++ )
        {
            for ( int c = 0; c < pixels[r].length - 1; c++ )
            {
                Color current = pixels[r][c];

                int red = swapBits( current.getRed() );
                int green = swapBits( current.getGreen() );
                int blue = swapBits( current.getBlue() );

                pixels[r][c] = new Color( red, green, blue );

            }
        }

        setBackground( pixels );

    } 

    /**
     * Get the swapped equivalent of a Byte, in integer format.
     * @param An integer that will have its last 8 bits exchanged (often a Color value).
     * @return An integer with the last 4 bits exchanged with the second to last 4 bits
     */
    private int swapBits( int number )
    {
        int right = ( number & 0x0F ) << 4;     // Grabs the last 4 bits, bitshifts them left 4 bits
        int left = ( number & 0xF0 ) >> 4;      // Grabs the second last 4 bits, bitshifts them right 4 bits
        return right | left;                    // Combines the two bitshifted numbers together
    }

    private int hideBits( int num1, int num2 )
    {
        num1 = num1 & 0xF0;             // Grabs the second to last 4 bits only
        num2 = ( num2 & 0xF0 ) >> 4;    // Grabs the second to last 4 bits, bitshifts them right 4
        return num1 | num2;             // Combines the two numbers together
    }

    //Drawing Examples
    public void drawRect( int startX, int startY, int width, int height )
    {
        Color color = new Color( (int)( Math.random() * 256 ),
                (int)( Math.random() * 256 ),
                (int)( Math.random() * 256 ));
        GreenfootImage img = getBackground();

        for ( int x = startX; x < startX + width; x++ )
        {
            for ( int y = startY; y < startY + height; y++ )
            {
                img.setColorAt( x, y, color );
            }
        }

    }

    // Demo Drawing Pen
    private int oldX, oldY;
    public void act()
    {
        draw();
        if ( Greenfoot.isKeyDown( "space" ) )
        {
            swapImage();
            Greenfoot.delay( 30 );
        }

        checkKeys();
    }

    public void swapImage()
    {
        String temp = filename;
        filename = alternate;
        alternate = temp;
        reset();        
    }

    public void draw()
    {
        GreenfootImage img = getBackground();
        MouseInfo m = Greenfoot.getMouseInfo();

        if( m != null )
        {
            if ( Greenfoot.mouseDragged( this ) )
            {
                img.drawLine( oldX, oldY, m.getX(), m.getY() );
            }
            else if ( Greenfoot.mousePressed( this ) )
            {
                img.setColor( Color.WHITE );
            }
            oldX = m.getX();
            oldY = m.getY();
        }
    }

    public void checkKeys()
    {
        if ( Greenfoot.isKeyDown( "a" ) )
        {
            reset();
            this.weirdGradientDemo();
        }
        if ( Greenfoot.isKeyDown( "b" ) )
        {
            reset();
            this.randomizeAllPixels();
        }
        if ( Greenfoot.isKeyDown( "c" ) )
        {
            reset();
            this.randomizeSolid();
        }
        if ( Greenfoot.isKeyDown( "d" ) )
        {
            reset();
            this.randomizeRows();
        }
        if ( Greenfoot.isKeyDown( "e" ) )
        {
            reset();
            this.randomizeColumns();
        }
        if ( Greenfoot.isKeyDown( "f" ) )
        {
            this.brighter();
        }
        if ( Greenfoot.isKeyDown( "g" ) )
        {
            this.darker();
        }
        if ( Greenfoot.isKeyDown( "h" ) )
        {
            reset();
            this.invert();
        }
        if ( Greenfoot.isKeyDown( "i" ) )
        {
            reset();
            this.invertRed();
        }
        if ( Greenfoot.isKeyDown( "j" ) )
        {
            reset();
            this.invertGreen();
        }
        if ( Greenfoot.isKeyDown( "k" ) )
        {
            reset();
            this.invertBlue();
        }
        if ( Greenfoot.isKeyDown( "l" ) )
        {
            reset();
            this.grayScale();
        }
        if ( Greenfoot.isKeyDown( "m" ) )
        {
            reset();
            this.redScale();
        }
        if ( Greenfoot.isKeyDown( "n" ) )
        {
            reset();
            this.redGrayScale();
        }
        if ( Greenfoot.isKeyDown( "o" ) )
        {
            reset();
            this.greenScale();
        }
        if ( Greenfoot.isKeyDown( "p" ) )
        {
            reset();
            this.greenGrayScale();
        }
        if ( Greenfoot.isKeyDown( "q" ) )
        {
            reset();
            this.blueScale();
        }
        if ( Greenfoot.isKeyDown( "r" ) )
        {
            reset();
            this.blueGrayScale();
        }
        if ( Greenfoot.isKeyDown( "s" ) )
        {
            reset();
            this.mirrorTopToBottom();
        }
        if ( Greenfoot.isKeyDown( "t" ) )
        {
            reset();
            this.mirrorBottomToTop();
        }
        if ( Greenfoot.isKeyDown( "u" ) )
        {
            reset();
            this.mirrorLeftToRight();
        }
        if ( Greenfoot.isKeyDown( "v" ) )
        {
            reset();
            this.mirrorRightToLeft();
        }
        if ( Greenfoot.isKeyDown( "w" ) )
        {
            reset();
            this.flipHorizontal();
        }
        if ( Greenfoot.isKeyDown( "x" ) )
        {
            reset();
            this.flipVertical();
        }
        if ( Greenfoot.isKeyDown( "y" ) )
        {
            reset();
            String answer = Greenfoot.ask("What threshold for edges? (An integer bigger than 0)");
            this.detectEdges( Integer.valueOf(answer) );
        }
        if ( Greenfoot.isKeyDown( "z" ) )
        {
            reset();
            String answer = Greenfoot.ask("How strong of a pixelation? (An integer bigger than 0)");
            this.pixelate( Integer.valueOf(answer) );
        }
        if ( Greenfoot.isKeyDown( "enter" ) )
        {
            reset();
            this.swapImage();
            Greenfoot.delay( 30 );
        }
        if ( Greenfoot.isKeyDown( "1" ) )
        {
            this.hideImage();
        }
        if ( Greenfoot.isKeyDown( "2" ) )
        {
            this.bitExchange();
        }
        
        
    }

}
