import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Wardrobe extends World
{
    private int timer = 2000;
    private int numCorrect = 0;

    private Robot robot1;
    private Robot robot2;

    public Wardrobe()
    {
        super(1100, 800, 1); 

        buildRobots();
    }

    public void act()
    {
        if ( robot1.equals( robot2 ) )
        {
            correctMatch();
        }

        updateTimer();
    }

    private void updateTimer()
    {        
        showText( "Timer\n" + timer / 20, 115, 365 );
        timer--;

        if ( timer <= 0 )
        {
            showText( "Score\n" + numCorrect, 115, 365 );
            Greenfoot.playSound( "horn end.wav" );
            Greenfoot.stop();
        }
    }

    public void correctMatch()
    {
        numCorrect++;
        Greenfoot.playSound( "sms.wav" );
        robot2.randomize();
    }

    private void buildRobots()
    {
        robot1 = new RobotPlayer();
        robot2 = new Robot();

        addObject( robot1, getWidth() / 4, getHeight() / 2 );
        addObject( robot2, getWidth() * 3 / 4, getHeight() / 2 );

        robot2.randomize();
    }
}
