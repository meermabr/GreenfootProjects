import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class RobotPlayer extends Robot
{
    private int row;
    private Selector selector;

    public void act() 
    {
        checkKeyPress();
        updateSelector();
    }

    public void checkKeyPress()
    {
        if ( Greenfoot.isKeyDown( "left" ) )
        {
            shift( NUM_OPTIONS - 1 );
        }
        if ( Greenfoot.isKeyDown( "right" ) )
        {
            shift( 1 );
        }
        if ( Greenfoot.isKeyDown( "up" ) )
        {            
            changeRows( NUM_TYPES - 1 );
        }
        if ( Greenfoot.isKeyDown( "down" ) )
        {
            changeRows( 1 );
        }
    }

    public void shift( int amount )
    {
        if ( row == HEAD_ROW )
        {
            setHeadNumber( (getHeadNumber() + amount ) % NUM_OPTIONS );
        }
        else
        {
            setTorsoNumber( (getTorsoNumber() + amount ) % NUM_OPTIONS );
        }
        wearOutfit();    
    }

    public void changeRows( int amount )
    {
        row = ( row + amount ) % NUM_TYPES;

        if ( row == DRESS_ROW )
        {
            setRobed( false );
        }
        else if ( row == ROBE_ROW )
        {
            setRobed( true );
        }

        wearOutfit();
    }

    public void updateSelector()
    {
        if ( selector == null )
        {            
            int midPoint = getWorld().getHeight() / 2;
            int xMidPoint = getWorld().getWidth() / 2;

            getWorld().showText( "Dresses", xMidPoint, midPoint );
            getWorld().showText( "Robes", xMidPoint, midPoint + 50 );
            getWorld().showText( "Masks", xMidPoint, midPoint - 50 );

            int [] locs = {midPoint - 50, midPoint, midPoint + 50}; 
            selector = new Selector(locs);
            getWorld().addObject( selector, getWorld().getWidth() / 2, 0 );
        }
        selector.changeLoc( row );
    }    
}
