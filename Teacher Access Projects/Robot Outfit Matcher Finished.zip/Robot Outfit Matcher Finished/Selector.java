import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Selector extends Actor
{    
    private int [] locations;
    
    public Selector( int [] locations )
    {
        this.locations = locations;
    }
    
    public void changeLoc( int index )
    {
        setLocation( getX(), locations[index] );
    }
}
