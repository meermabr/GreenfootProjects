import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class Robot extends Actor
{
    protected static final int HEAD_ROW = 0;    
    protected static final int DRESS_ROW = 1;
    protected static final int ROBE_ROW = 2;    
    protected static final int NUM_TYPES = 3;
    protected static final int NUM_OPTIONS = 8;
    private static final int DELAY_TIME = 10;

    protected CostumePiece [][] attire;
    private int headNumber;
    private int torsoNumber;
    private boolean robed;

    public Robot()
    {
        buildAttire();
    }

    public void randomize()
    {
        torsoNumber = (int)(Math.random() * attire[0].length);
        headNumber = (int)(Math.random() * attire[0].length);

        robed = Math.random() < 0.5;

        wearOutfit();
    }

    public void removeAll()
    {
        for ( CostumePiece[] costumes : attire )
        {
            getWorld().removeObjects( Arrays.asList( costumes ) );            
        } 
    }

    public void setTorsoNumber(int num)
    {
        torsoNumber = num;
    }

    public void setHeadNumber(int num)
    {
        headNumber = num;
    }

    public void setRobed( boolean isRobed )
    {
        robed = isRobed;
    }

    public int getTorsoNumber()
    {
        return torsoNumber;
    }

    public int getHeadNumber()
    {
        return headNumber;
    }

    public boolean isRobed()
    {
        return robed;
    }

    public void buildAttire()
    {
        attire = new CostumePiece[NUM_TYPES][NUM_OPTIONS];
        for ( int c = 0; c < attire[0].length; c++ )
        {
            attire[DRESS_ROW][c] = new CostumePiece("dress", c + 1);
            attire[ROBE_ROW][c] = new CostumePiece("robe", c + 1);
            attire[HEAD_ROW][c] = new CostumePiece("mask", c + 1);
        }    
    }

    public void wearOutfit()
    {   
        Greenfoot.delay( DELAY_TIME );
        removeAll(); 
        if ( isRobed() )
        {
            getWorld().addObject( attire[ROBE_ROW][getTorsoNumber()], getX(), getY() );
        }
        else
        {
            getWorld().addObject( attire[DRESS_ROW][getTorsoNumber()], getX(), getY() );
        }
        getWorld().addObject( attire[HEAD_ROW][getHeadNumber()], getX(), getY() );
        
    }

    public boolean equals( Robot other )
    {
        return  this.getHeadNumber() == other.getHeadNumber() &&
                this.getTorsoNumber() == other.getTorsoNumber() &&
                this.isRobed() == other.isRobed();  
    }
}
