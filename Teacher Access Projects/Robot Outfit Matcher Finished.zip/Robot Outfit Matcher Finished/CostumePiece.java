import greenfoot.*;  

public class CostumePiece extends Actor
{
    public CostumePiece( String type, int number )
    {
        setImage( type + number + ".png" );
    }
}
