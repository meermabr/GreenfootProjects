import greenfoot.*;

public class Note extends SmoothMover
{
    GreenfootImage originalImg;
    private int number;
    private double dx;
    private double dy = 6;
    
    public Note( int number )
    {
        setImage( "note" + number + ".png" );
        this.number = number;
        switch ( number )
        {
            case 1: dx = -.85;    break;
            case 2: dx = -0.45;   break;
            case 3: dx = 0;       break;
            case 4: dx = 0.45;    break;
            default: dx = .85;
        }
        
    }
    
    public void act() 
    {
        scaleImage();
        setLocation( getExactX() + dx, getExactY() + dy );
        
        if ( isAtEdge() )
        {
            getWorld().removeObject( this );
            Score.adjustScore(-500);
            Greenfoot.playSound("Glass Break.mp3");
        }
    }    
    
    public void scaleImage()
    {
        setImage( "note" + number + ".png" );        
        
        double percent = 44.0 / 567 * getY() + 284.0 / 9;
        percent /= 100;
        int width = (int)(percent * 90);
        int height = (int)(percent * 82);
        getImage().scale(width, height);
    }
    
}
