import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Notification extends Actor
{
    private int timer = 50;
    
    public Notification( int distance )
    {
        if ( distance > 30 )
        {
            Greenfoot.playSound("Glass Break.mp3");
            setImage( "late.png" );
            Score.adjustScore(-20);
        }
        else if ( distance < -30 )
        {
            Greenfoot.playSound("Glass Break.mp3");
            setImage( "early.png" );
            Score.adjustScore(-20);
        }
        else if ( Math.abs(distance) > 15 )
        {
            setImage( "close.png" );
            Score.adjustScore(200);
        }
        else
        {
            setImage( "perfect.png" );
            Score.adjustScore(300);
        }
    }
        
    public void act() 
    {
        timer--;
        if ( timer <= 0 )
        {
            getWorld().removeObject( this );
        }
    }    
}
