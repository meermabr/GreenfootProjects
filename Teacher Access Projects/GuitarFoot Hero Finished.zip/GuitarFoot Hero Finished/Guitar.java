import greenfoot.*;  

public class Guitar extends World
{

    private GreenfootSound music;
    
    public Guitar()
    {    
        super(800, 1035, 1); 
        
        buildFrets();
        addObject( new Score(), 300, 100 );
        addObject( new Instructions(), 700, 270 );
    }
    
    
    public void buildFrets()
    {
        for ( int i = 0; i < 5; i++ )
        {
            addObject( new Fret( i + 1 ), i * 92 + 234, 882 );
        }
    }
    
    public void act()
    {
        if ( music == null )
        {
            music = new GreenfootSound( "Eddy - Pure Adrenaline.mp3" );
            music.playLoop();
        }
        
        if ( Math.random() < 0.01 )
        {
            addRandomNote();
        }        
        else if ( Math.random() < 0.005 )
        {
            addDoubleNote();
        }
    }
    
    public void addRandomNote()
    {
        
        int num = (int)(Math.random() * 5 );
        addObject( new Note( num + 1 ), num * 53 + 313, 315 );
    }

    public void addDoubleNote()
    {
        
        int num = (int)(Math.random() * 4 );
        addObject( new Note( num + 1 ), num * 53 + 313, 315 );
        addObject( new Note( num + 2 ), (num + 1) * 53 + 313, 315 );
    }
    
    
}
