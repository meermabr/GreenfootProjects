import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Score extends Actor
{
    private static int score;
    private static int streak;
    private GreenfootImage img;

    public Score()
    {
        img = new GreenfootImage( 600, 300 );
        
        img.setColor( Color.BLACK );
        img.setFont(new Font("Courier", true, false, 50 ) );
        setImage( img );

        score = 0;
        streak = 0;
    }

    public void act() 
    {
        getImage().clear();

        int numDigits = String.valueOf( score ).length();
        getImage().drawString("Score:  " + score, 10, img.getHeight() / 2  - 30);

        numDigits = String.valueOf( streak ).length();
        getImage().drawString("Streak: " + streak, 10, img.getHeight() / 2 + 20);
    }    

    public static void adjustScore( int amount )
    {
        if ( amount > 0 )
        {
            streak++;
        }
        else
        {
            streak = 1;
        }

        score += amount * streak;

        if ( amount < 0 )
        {
            streak = 0;
        }
    }

}
