import greenfoot.*; 
import java.util.*;

public class Fret extends Actor
{
    private String myKey;
    private GreenfootImage upImage, downImage;

    public Fret( int number )
    {
        myKey = "" + number;
        upImage = new GreenfootImage( "fret" + number + "up.png" );
        downImage = new GreenfootImage( "fret" + number + "down.png" );
        setImage( downImage );
    }

    public void act() 
    {
        if ( Greenfoot.isKeyDown( myKey ) )
        {
            setImage( downImage );
            if ( Greenfoot.isKeyDown( "enter" ) )
            {
                List<Note> notes = this.getObjectsInRange(40, Note.class);

                if ( !notes.isEmpty() )
                {
                    score(notes.get( 0 ));
                    removeTouching( Note.class );
                }
            }

        }
        else
        {
            setImage( upImage );
        }
    }    

    public void score( Note n )
    {
        int distance = n.getY() - getY();
        getWorld().addObject( new Notification(distance), getX(), getY() + 50 );
    }

}
