import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class MyWorld extends World
{
    private static final int Y_LINE = 650;
    
    private List<Animal> animals;

    public MyWorld()
    {    
        super(1000, 800, 1); 
        buildAnimals();
        buildButtons();
    }

    public void sortAnimals()
    {
        Collections.sort( animals );
    }    

    public void selectionSort()
    {
        for ( int i = 0; i < animals.size() - 1; i++ )
        {
            int smallestIndex = i;
            for ( int j = i + 1; j < animals.size(); j++ )
            {
                if ( animals.get( j ).getHeight() < animals.get( smallestIndex ).getHeight() )
                {
                    smallestIndex = j;
                }
            }

            swap( i, smallestIndex );
        }

    }

    public void insertionSort()
    {
        for ( int i = 1; i < animals.size(); i++ )
        {
            Animal a = animals.get( i );
            pull( i );

            int xLoc = a.getX();
            int j = i - 1;

            while ( j >= 0 && animals.get(j).getHeight() > a.getHeight() )
            {
                int tempX = animals.get( j ).getX();
                slide( j, xLoc );
                xLoc = tempX;

                animals.set( j + 1, animals.get( j ) );
                j--;
            }
            animals.set( j + 1, a );
            slide( j + 1, xLoc );
            pull( j + 1 );

        }
    }

    public void swap(int index1, int index2)
    {
        //Leave this line to visually see the swap.
        visualSwap( index1, index2 );

        //The list itself still needs its indices swapped
        Animal temp = animals.get(index1);
        animals.set( index1, animals.get(index2) );
        animals.set( index2, temp );
    }
    
    public void randomize()
    {
        Collections.shuffle( animals );
        visualLineUp();
    }
    

    /**
     * Builds the ArrayList of Animals and places each on the screen.
     * Uses one each of the Animal images.
     */
    public void buildAnimals()
    {
        animals = new ArrayList<>();

        for ( int i = 0; i < Animal.NUM_ANIMALS; i++ )
        {
            animals.add( new Animal( i ) );

            Animal a = animals.get( i );

            addObject( a, 0, Y_LINE - a.getImage().getHeight() / 2);
        }

        randomize();
    }
    
    /**
     * Places the insertion and selection sort buttons.
     */
    public void buildButtons()
    {
        addObject( new InsertionSort(), getWidth() * 3 / 4, 40 );
        addObject( new SelectionSort(), getWidth() * 2 / 4, 40 );
        addObject( new Randomize(), getWidth() / 4, 40 );
    }

    /**
     * Lines up all animals in the List in current index order.
     * The animal in the first index will be farther left
     * and the animal in the last index will be farthest right.
     * This has no delay and will quickly show the lineup.
     */
    public void visualLineUp()
    {
        int gap = getWidth() / animals.size();
        for ( int x = 0; x < animals.size(); x++ )
        {
            Animal a = animals.get( x );
            a.setLocation( x * gap + gap / 2, a.getY() );
        }
    }

    /**
     * Swaps two animals in the line at given indices.
     * The List is unchanged itself, only the physical
     * locations on the screen are modified.
     * 
     * This takes time to do. Alternately visualLineUp
     * may be used to instantly view the current order
     * of the List.
     * 
     * @param index1 The first index to be swapped.
     * @param index2 The second index to be swapped.
     */
    private void visualSwap( int index1, int index2 )
    {
        if ( index1 == index2 )
        {
            pull( index1 );
            pull( index1 );
            return;
        }

        pull( index1 );
        pull( index2 );
        
        slide2( index1, index2 );

        pull( index1 );
        pull( index2 );

    }

    private void pull( int index )
    {
        Animal a = animals.get( index );
        
        int dy = 4;
        if ( a.getY() > Y_LINE - a.getImage().getHeight() / 2 )
        {
            dy = -4;
        }
        
        for ( int y = 0; y < 25; y++ )
        {
            a.setLocation( a.getX(), a.getY() + dy );
            Greenfoot.delay( 1 );
        } 
    }

    private void slide(int index, int xDestination)
    {
        Animal a = animals.get( index );
        int moveAmount = Math.abs( a.getX() - xDestination );

        int moveDistance = 5;
        if ( a.getX() > xDestination )
        {
            moveDistance = -5;
        }

        for ( int x = 0; x < moveAmount; x += Math.abs(moveDistance) )
        {
            a.move( moveDistance );
            Greenfoot.delay( 1 );
        }
    }

    private void slide2( int index1, int index2 )
    {
        Animal a = animals.get( index1 );
        Animal b = animals.get( index2 );

        int moveAmount = Math.abs( a.getX() - b.getX() );

        int moveDistance = 5;
        if ( a.getX() > b.getX() )
        {
            moveDistance = -5;
        }

        for ( int x = 0; x < moveAmount; x += Math.abs(moveDistance) )
        {
            a.move( moveDistance );
            b.move( -moveDistance );
            Greenfoot.delay( 1 );
        }
    }

}
