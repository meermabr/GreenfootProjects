import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Animal extends Actor implements Comparable<Animal>
{
    public static final int NUM_ANIMALS = 22; 
    
    public Animal(int number)
    {
        setImage( "animal" + number + ".png" );
        GreenfootImage img = getImage();
        img.scale( img.getWidth() / 3, img.getHeight() / 3 );
    }
    
    public Animal()
    {
        this( (int)(Math.random() * NUM_ANIMALS ) );
    }
    
    public int getHeight()
    {
        return getImage().getHeight();
    }
    
    public int getWidth()
    {
        return getImage().getWidth();
    }
    
    public int compareTo( Animal other )
    {
        return getHeight() - other.getHeight();
    }
    
}
