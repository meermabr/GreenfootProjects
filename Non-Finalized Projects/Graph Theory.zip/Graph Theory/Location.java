import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Location extends Actor
{
    public String toString()
    {
        return "(" + getX() + "," + getY() + ")";
    }
    
    public int hashCode()
    {
        return toString().hashCode();
    }
    
    public boolean equals( Location other )
    {
        return this.toString().equals( other.toString() );
    }
}
