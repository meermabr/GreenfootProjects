import greenfoot.*;

public class PrimsButton extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            MyWorld w = (MyWorld)getWorld();
            w.primMinimumSpanningTree();
        }
    }    
}
