import greenfoot.*;  

public class Edge implements Comparable<Edge>
{
    private Location vertex1;
    private Location vertex2;
    
    public Edge(Location vertex1, Location vertex2)
    {
        this.vertex1 = vertex1;
        this.vertex2 = vertex2;
    }
    
    public void show(World w ) 
    {
        GreenfootImage bg = w.getBackground();
        bg.setColor( Color.ORANGE );
        bg.drawLine( vertex1.getX(), vertex1.getY(), vertex2.getX(), vertex2.getY() );
    }    
    
    public double getDistance()
    {
        double dx = vertex1.getX() - vertex2.getX();
        double dy = vertex1.getY() - vertex2.getY();
        return Math.sqrt( dx * dx + dy * dy );
    }
    
    public int compareTo( Edge other )
    {
        Double d1 = getDistance();
        Double d2 = other.getDistance();
        return d1.compareTo( d2 );
    }
    
    public Location getVertex1()
    {
        return vertex1;
    }
    
    public Location getVertex2()
    {
        return vertex2;
    }
    
}
