import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RandomButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RandomButton extends Actor
{    
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            String input = Greenfoot.ask( "How many locations would you like? " );
            int x;
            try {
                x = Integer.parseInt(input);
            }
            catch ( Exception e ) {
                x = 20;
            }
            
            MyWorld w = (MyWorld)getWorld();
            w.randomPopulate(x);
        }
    }    
}
