import greenfoot.*;  

public class ConnectionButton extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) ) 
        {
            MyWorld w = (MyWorld)getWorld();
            w.buildConnections();
            w.showConnections();
        }
    }    
}
