import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class MyWorld extends World
{
    private PriorityQueue<Edge> edges;

    public MyWorld()
    {    
        super(961, 604, 1); 
        edges = new PriorityQueue<>();

        addObject( new RandomButton(), 90, 480 );
        addObject( new ConnectionButton(), 90, 520 );
        addObject( new PrimsButton(), 90, 560 );
    }

    public void randomPopulate( int amount )
    {
        removeObjects( getObjects(Location.class ));
        setBackground( "WorldMap.png" );
        GreenfootImage bg = getBackground();
        
        while ( amount > 0 )
        {
            int x = (int)(Math.random() * getWidth() );
            int y = (int)(Math.random() * getHeight() );

            if ( !bg.getColorAt( x, y ).equals( Color.WHITE ) )
            {
                addObject( new Location(), x, y );
                amount--;
            }
        }

    }

    public void buildConnections()
    {
        List<Location> locs = getObjects( Location.class );
        for ( int i = 0; i < locs.size(); i++ )
        {
            for ( int j = i + 1; j < locs.size(); j++ )
            {
                Edge e = new Edge( locs.get( i ), locs.get( j ) );
                edges.add( e );
            }
        }            
    }

    public void showConnections()
    {
        for ( Edge e : edges )
        {
            e.show( this );
            Greenfoot.delay( 5 );
        }
    }

    public void primMinimumSpanningTree()
    {
        List<Location> locs = getObjects( Location.class );
        if ( locs.isEmpty() )
        {
            return;
        }

        HashSet<Location> visited = new HashSet<>();
        HashSet<Location> unvisited = new HashSet<>(locs);
        visited.add( locs.get(0) );
        unvisited.remove( locs.get(0) );

        while ( !unvisited.isEmpty() ) 
        {
            PriorityQueue<Edge> edges = buildAllEdges( visited, unvisited );
            Edge e = edges.remove();

            Location v1 = e.getVertex1();
            Location v2 = e.getVertex2();

            e.show( this );
            Greenfoot.delay( 4 );
            unvisited.remove( v1 );
            unvisited.remove( v2 );
            visited.add( v1 );
            visited.add( v2 );

        }

    }

    private PriorityQueue<Edge> buildAllEdges( Set<Location> visited, Set<Location> unvisited )
    {
        PriorityQueue<Edge> remainingEdges = new PriorityQueue<>();
        for ( Location loc1 : visited )
        {
            for ( Location loc2 : unvisited )
            {
                remainingEdges.add( new Edge( loc1, loc2 ) );
            }
        }
        return remainingEdges;
    }

}
