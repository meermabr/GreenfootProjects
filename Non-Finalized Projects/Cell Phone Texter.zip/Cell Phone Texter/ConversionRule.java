import java.util.*;

public class ConversionRule  
{
    private String find;
    private String replace;
    
    private List<ConversionRule> conversions;
    
    public ConversionRule(String find, String replace)
    {
        this.find = find;
        this.replace = replace;
        
    }
    
    public String convert( String phrase )
    {
        String ans = "";
        
        int i = 0;
        
        while ( i < phrase.length() - find.length() + 1 )
        {
            if ( phrase.substring( i, i + find.length() ).equals( find ) )
            {
                ans += replace;
                i += find.length();
            }
            else
            {
                ans += phrase.substring( i, i + 1 );
                i++;
            }
        }
        ans += phrase.substring( i );
        return ans;
    }    
}
