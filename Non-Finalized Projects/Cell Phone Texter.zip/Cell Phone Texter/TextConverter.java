import java.util.*;

public class TextConverter  
{
    private static List<ConversionRule> conversions;

    private static void buildConversions()
    {   
        conversions = new ArrayList<>();
        
        conversions.add( new ConversionRule("4", "for") );
        conversions.add( new ConversionRule("u", "you") );
        conversions.add( new ConversionRule("3", "e") );
        conversions.add( new ConversionRule("lol", "laugh out loud") );
        conversions.add( new ConversionRule("^^", "read above") );
        conversions.add( new ConversionRule("@TEOTD", "at the end of the day") );
        conversions.add( new ConversionRule(".02", "my two cents worth") );
        conversions.add( new ConversionRule("14AA41", "one for all and all for one") );
        conversions.add( new ConversionRule("10Q", "thank you") );
    }

    public static String convertMessage( String message )
    {
        if ( conversions == null )
        {
            buildConversions();
        }
        
        for ( ConversionRule c : conversions )
        {
            message = c.convert(message);
        }
        
        return message.toString();
    }

}
