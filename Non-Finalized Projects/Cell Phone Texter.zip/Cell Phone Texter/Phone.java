import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Phone extends Actor
{
    private String userName;
    private GreenfootImage icon;
    private Button button;

    private Phone connectedPhone;
    private int y = 145;
    private int nextLine = 30;
    
    private static final int bottomY = 190;

    public Phone( String userName, String iconName )
    {
        this.userName = userName;
        icon = new GreenfootImage( iconName );
        getImage().setFont( new Font("calibri", 15) );
        getImage().scale( getImage().getWidth() * 2 / 3, getImage().getHeight() * 2 / 3 );
        
    }

    public void connectTo( Phone other )
    {
        connectedPhone = other;
    }    

    public String getUserName()
    {
        return userName;
    }

    public GreenfootImage getIcon()
    {
        return icon;
    }

    public void sendMessage()
    {
        if ( connectedPhone != null )
        {
            String message = Greenfoot.ask( "Enter a message." );
            String converted = TextConverter.convertMessage(message);

            displayMessage( message, true );
            connectedPhone.displayMessage( converted, false );
        }
    }

    public void drag()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        if ( m != null )
        {
            setLocation( m.getX(), m.getY() );
            button.setLocation( getX(), getY() + bottomY );

            if ( isTouching( Phone.class ) )
            {
                Phone p = (Phone)this.getOneIntersectingObject(Phone.class);
                p.connectTo( this );
                connectTo( p );
            }

        }       
    }

    public void act() 
    {
        if ( button == null )
        {
            button = new Button( this );
            getWorld().addObject( button, getX(), getY() + bottomY );
        }

        if ( Greenfoot.mouseDragged( this ) )
        {
            drag();
        }

    }    

    public void displayMessage( String message, boolean myPhone )
    {
        if ( myPhone )
        {
            getImage().drawImage(icon, 30, y - icon.getHeight() / 2);

            getImage().setColor( Color.BLACK );
            getImage().drawString( "Me: " + message, 60, y );
            y += nextLine;
        }
        else
        {      
            GreenfootImage other = connectedPhone.getIcon();
            getImage().drawImage(other, 30, y - other.getHeight() / 2);

            getImage().setColor( Color.BLUE );
            getImage().drawString( connectedPhone.getUserName() + ": " + message, 60, y );
            y += nextLine;
        }
    }

}
