import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Button extends Actor
{
    private Phone myPhone;
    
    public Button( Phone phone )
    {
        myPhone = phone;
    }
    
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            myPhone.sendMessage();
        }
        
    }    
}
