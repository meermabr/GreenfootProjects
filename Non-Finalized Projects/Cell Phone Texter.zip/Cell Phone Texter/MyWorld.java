import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class MyWorld extends World
{
    public MyWorld()
    {    
        super(1000, 1000, 1); 
        Phone a = new Phone( "Bob", "icon1.png" );
        Phone b = new Phone( "Sally", "icon2.png" );
        addObject( a, getWidth() / 4, getHeight() / 4 );
        addObject( b, getWidth() * 3 / 4, getHeight() / 4 );
        
        
        Phone c = new Phone( "Sue", "icon3.png" );
        Phone d = new Phone( "John", "icon4.png" );
        addObject( c, getWidth() / 4, getHeight() * 3 / 4 );
        addObject( d, getWidth() * 3 / 4, getHeight() * 3 / 4 );
        
        a.connectTo( b );
        b.connectTo( a ); 
        
    }
}
