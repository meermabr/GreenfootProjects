public class TextMessage  
{
    private String message;
    private String sender;
    private String receiver;
    
    public TextMessage(String message, String sender, String receiver)
    {
        this.message = message;
        this.sender = sender;
        this.receiver = receiver;
    }
    
    public String getMessage()
    {
        return message;
    }

    public String getSender()
    {
        return sender;
    }
    
    public String getReciever()
    {
        return receiver;
    }
    
    public String getMessageConverted()
    {
        return TextConverter.convertMessage(message);
    }
}
