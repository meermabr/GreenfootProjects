import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Snowman here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Snowman extends Actor
{
    private static final int MAX_X = 300;
    
    
    private int delayTimer;
    private int power;
    private boolean increasingPower;
    private int hitpoints = 5;
    
    
    public Snowman()
    {
        int number = (int)(Math.random() * 6);
        setImage( "snow" + number  + ".png" );
    }
    
    
    

    public void act() 
    {
        if ( Greenfoot.isKeyDown( "right" ) && getX() < MAX_X ) 
        {
            move( 2 );
        }
        else if ( Greenfoot.isKeyDown( "left" ) )
        {
            move( -2 );
        }
        
        
        delayTimer--;

        if ( delayTimer < 0 )
        {
            
            if ( delayTimer % 5 == 0 && increasingPower )
            {
                power++;
                if ( power >= 9 )
                {
                    increasingPower = false;
                }
            }
            else if ( delayTimer % 5 == 0 )
            {
                power--;
                if ( power <= 0 )
                {
                    increasingPower = true;
                }
            }
            

            getWorld().showText( "Power: " + power, 100, 780);
            
            if ( Greenfoot.isKeyDown( "space" ) ) 
            {
                Snowball ball = new Snowball(power * 4, -30);
                getWorld().addObject( ball, getX()+30, getY() - 130 );
                delayTimer = 100;
                power = 0;
                increasingPower = true;
            }

        }

        getWorld().showText( "Hitpoints: " + hitpoints, 100, 800 );
        if ( hitpoints <= 0 )
        {
            getWorld().removeObject(this);
        }
        
    }    
    
    
    
    public void hit()
    {
        hitpoints--;
    }
}
