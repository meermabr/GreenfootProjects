import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Snowball extends SmoothMover
{
    private static final double gravity = 1.5;
    private double windFriction = 0.99;
    
    private double velocityX;
    private double velocityY;
    
    
    
    public Snowball( double velocityX, double velocityY )
    {
        this.velocityX = velocityX;
        this.velocityY = velocityY;
    }
    
    public void act() 
    {
        velocityY += gravity;
        velocityX *= windFriction;
        
        setLocation( getX() + velocityX, getY() + velocityY );
        
        if ( isTouching( Snowman.class ) )
        {
            Snowman snowy = (Snowman)this.getOneIntersectingObject( Snowman.class );
            snowy.hit();            
            getWorld().removeObject( this );
        }
        
        else if ( isAtEdge() )
        {
            getWorld().removeObject( this );
        }
    }    
}
