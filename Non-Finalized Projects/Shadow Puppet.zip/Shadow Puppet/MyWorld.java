import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class MyWorld extends World
{

    public MyWorld()
    {    
        super(1163, 910, 1); 
    }

    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            setupPuppet();
        }
    }

    public void setupPuppet()
    {
        Silhouette s = new Silhouette();
        Puppet p = new Puppet(s);

        MouseInfo m = Greenfoot.getMouseInfo();
        
        addObject( s, m.getX(), m.getY() );
        addObject( p, m.getX(), m.getY() );

    }

}
