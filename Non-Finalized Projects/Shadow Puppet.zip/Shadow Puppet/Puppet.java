import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Puppy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Puppet extends SmoothMover
{
    private Silhouette mySilhouette;
    private int oldX, oldY;
    private static final double MULTIPLIER = 0.003;
    

    public Puppet( Silhouette s ) 
    {
        mySilhouette = s;
    }

    public void act() 
    {
        
        checkMouseMovement();
    }
    
    public void checkMouseMovement()
    {
        MouseInfo m = Greenfoot.getMouseInfo();

        if ( Greenfoot.mousePressed( this ) )
        {
            oldX = m.getX();
            oldY = m.getY();
        }

        if ( Greenfoot.mouseDragged( this  ) )
        {

            int differenceX = m.getX() - getX();
            int differenceY = m.getY() - getY();

            setLocation( m.getX(), m.getY() );
            mySilhouette.setLocation( mySilhouette.getX() - differenceX,
                mySilhouette.getY() - differenceY );

            resizeSilhouette();
        }     
    }    
    
    public void resizeSilhouette()
    {
        mySilhouette.scale( distanceToSilhouette() * MULTIPLIER );
    }
    
    public double distanceToSilhouette()
    {
        return Math.sqrt( Math.pow( getX() - mySilhouette.getX(), 2 ) + Math.pow( getY() - mySilhouette.getY(), 2 ) );        
    }
    
}
