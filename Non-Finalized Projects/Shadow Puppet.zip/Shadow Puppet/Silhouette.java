import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Silhouette here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Silhouette extends SmoothMover
{    
    private final int ORIGINAL_WIDTH;
    private final int ORIGINAL_HEIGHT;
    private GreenfootImage original;
    
    public Silhouette()
    {
        ORIGINAL_WIDTH = getImage().getWidth();
        ORIGINAL_HEIGHT = getImage().getHeight();
        
        original = new GreenfootImage( getImage() );
    }
    
    public void scale( double amount )
    {
        setImage( original );
        
        original = new GreenfootImage( getImage() );
        getImage().scale( (int)(ORIGINAL_WIDTH * amount), (int)(ORIGINAL_HEIGHT * amount) );
    }
    
}
