import greenfoot.*;

public class MusicPlayer extends World
{
    
    
    public MusicPlayer()
    {    
        super(1024, 768, 1); 
    }

    
}
