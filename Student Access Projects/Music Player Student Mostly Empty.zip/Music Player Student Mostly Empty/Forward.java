import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Forward extends Actor
{
    public void act() 
    {

    }    
}
