import greenfoot.*; 

public class StarFish extends Actor
{
    public void act() 
    {
        
    }    
}
