import greenfoot.*;

public class ClownFish extends Actor
{
    public void act() 
    {
        move( 5 );
        turn( -2 );
    }    
}

