import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Aquarium extends World
{

    public Aquarium()
    {    
        super(1136, 935, 1); 
    }
    
    public void act()
    {
    }
    
}
