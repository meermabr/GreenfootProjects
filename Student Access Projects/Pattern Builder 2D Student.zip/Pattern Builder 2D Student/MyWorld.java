import greenfoot.*;

public class MyWorld extends ArrayWallWorld
{
    private static final int DEFAULT_ROWS = 45;
    private static final int DEFAULT_COLS = 57;

    public MyWorld()
    {    
        super(DEFAULT_ROWS, DEFAULT_COLS );
    }

    public MyWorld( int numRows, int numCols )
    {
        super( numRows, numCols );
    }

    public void allMiddle()
    {
        boolean [][] walls = new boolean[getNumRows()][getNumCols()];

        for ( int r = 1; r < walls.length - 1; r++ )
        {
            for ( int c = 1; c < walls[r].length - 1; c++ )
            {
                walls[r][c] = true;
            }
        }
        draw2D( walls );
    }

    public void border()
    {
    }

    public void checkered()
    {
    } 

    public void diagonals()
    {
    }

    public void exterior()
    {
    }

    public void fibonacci()
    {
    }

    public void geometricSeries()
    {
    }  

    public void hemisphereLeft()
    {
    }

    public void hemisphereRight()
    {
    }

    public void hemisphereTop()
    {
    }

    public void hemisphereBottom()
    {  
    }

    public void isosclesRightA()
    {  
    }

    public void isosclesRightB()
    {
    }    

    public void isosclesRightC()
    {
    }

    public void isosclesRightD()
    {
    }      

    public void jaggedSteps()
    {
    }

    public void knitting()
    {
    }

    public void longitudes()
    {
    }

    public void latitudes()
    {
    }

    public void act()
    {
        if ( Greenfoot.isKeyDown( "a" ) )
        {
            this.allMiddle();
        }
        if ( Greenfoot.isKeyDown( "b" ) )
        {
            this.border();
        }
        if ( Greenfoot.isKeyDown( "c" ) )
        {
            this.checkered();
        }
        if ( Greenfoot.isKeyDown( "d" ) )
        {
            this.diagonals();
        }
        if ( Greenfoot.isKeyDown( "e" ) )
        {
            this.exterior();
        }
        if ( Greenfoot.isKeyDown( "f" ) )
        {
            this.fibonacci();
        }
        if ( Greenfoot.isKeyDown( "g" ) )
        {
            this.geometricSeries();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "1" ) )
        {
            this.hemisphereLeft();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "2" ) )
        {
            this.hemisphereRight();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "3" ) )
        {
            this.hemisphereTop();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "4" ) )
        {
            this.hemisphereBottom();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "1" ))
        {
            this.isosclesRightA();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "2" ))
        {
            this.isosclesRightB();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "3" ))
        {
            this.isosclesRightC();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "4" ))
        {
            this.isosclesRightD();
        }
        if ( Greenfoot.isKeyDown( "j" ) )
        {
            this.jaggedSteps();
        }
        if ( Greenfoot.isKeyDown( "k" ) )
        {
            this.knitting();
        }
        if ( Greenfoot.isKeyDown( "l" ) && Greenfoot.isKeyDown( "1" ))
        {
            this.latitudes();
        }
        if ( Greenfoot.isKeyDown( "l" ) && Greenfoot.isKeyDown( "2" ))
        {
            this.longitudes();
        }
        if ( Greenfoot.isKeyDown( "F1" ) )
        {
            MyWorld w = new MyWorld(DEFAULT_ROWS, DEFAULT_COLS);
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F2" ) )
        {
            MyWorld w = new MyWorld( DEFAULT_COLS, DEFAULT_ROWS );
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F3" ) )
        {
            MyWorld w = new MyWorld( DEFAULT_ROWS / 2, DEFAULT_COLS / 2 );
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F4" ) )
        {
            MyWorld w = new MyWorld( DEFAULT_COLS / 2, DEFAULT_ROWS / 2 );
            Greenfoot.setWorld( w );
        }

        if ( Greenfoot.isKeyDown( "F5" ) )
        {
            int randRow = (int)(Math.random() * 50 ) + 10;
            int randCol = (int)(Math.random() * 50 ) + 10;

            MyWorld w = new MyWorld( randRow / 2, randCol / 2 );
            Greenfoot.setWorld( w );
        }
    }
}