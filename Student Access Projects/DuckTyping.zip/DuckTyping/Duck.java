import greenfoot.*;

public class Duck extends SmoothMover
{

    
    //Leave this myKey alone. Read it to see if you can understand
    //how it generates a letter randomly, it is similar to an
    //(int)(Math.random() * __ ) + ___ but this time I wanted a char.
    private String myKey = "" + (char)(Math.random() * 26 + 'A');

    public Duck()
    {
        //This is called a Constructor. 
        //The constructor is called the moment a Duck is built.
        //Leave this section alone, it draws the Duck's letter/key on the Duck
        GreenfootImage img = getImage();
        img.setFont(new Font("VERDANA", true, false, 20));
        img.drawString(myKey, 50, 80 );
    }

    public void act() 
    {

    }    
}
