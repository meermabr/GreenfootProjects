import greenfoot.*;

public class Water extends World
{
    
    public Water()
    {    
        super(1000, 800, 1); 
        
        
         
    }

    public void act()
    {
     
    }
}
