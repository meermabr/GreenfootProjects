import greenfoot.*;

public class Gator extends Actor
{
    // No code to do here unless you want to add some yourself
    
    // It is fun to make the Gators walk across the screen
    // then teleport back to the left side.
    public void act()
    {
    }
}
