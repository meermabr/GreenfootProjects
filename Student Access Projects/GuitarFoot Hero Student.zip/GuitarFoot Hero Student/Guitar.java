import greenfoot.*;  

public class Guitar extends World
{
    
    public Guitar()
    {    
        super(800, 1035, 1); 
        
    }
    
    
    public void act()
    {
        
        
    }    
    
}
