import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Play extends Actor
{
    private boolean playButton = true;
    
    private static final String pauseImage = "pause.png";
    private static final String playImage = "play.png";

    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            changeMode();
        }
    }    

    public void changeMode()
    {
        playButton = !playButton;

        MyWorld w = (MyWorld)getWorld();
        
        if ( playButton )
        {
            w.pause(); 
            setImage( playImage );
        }
        else
        {
            w.play();
            setImage( pauseImage );
        }
    }
}
