import greenfoot.*;

public class MyWorld extends World
{
    private GreenfootSound song;
    
      
    public MyWorld()
    {    
        super(1024, 768, 1); 
        prepare();
    }
            
    public void next()
    {
    }
       
    public void back()
    { 
    }

    public void play()
    {
    }
    
    public void pause()
    {
    }
    
    public void stop()
    {
    }
    
    private void prepare()
    {
    }
}
