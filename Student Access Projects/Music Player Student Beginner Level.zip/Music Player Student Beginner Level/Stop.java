import greenfoot.*;  
public class Stop extends Actor
{
    public void act() 
    {
        
    }    
}
