import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Wardrobe extends World
{
    public Wardrobe()
    {
        super(1100, 800, 1); 
    }

    public void act()
    {
    }

}
