import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class RobotPlayer extends Robot
{
    
    
    public void act()
    {
        
    }
}
