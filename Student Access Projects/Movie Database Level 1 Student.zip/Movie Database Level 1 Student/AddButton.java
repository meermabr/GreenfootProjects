import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AddButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AddButton extends Actor
{
    /**
     * Act - do whatever the AddButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            String title = Greenfoot.ask("What movie title do you want to add?" );
            int year = Integer.parseInt(Greenfoot.ask("What year was " + title + " made?" ));
            String description = Greenfoot.ask("Give a short description of " + title + ".");
            
            MovieDatabase m = (MovieDatabase)getWorld();
            m.addMovie( title, year, description );
            
        }
    }    
}
