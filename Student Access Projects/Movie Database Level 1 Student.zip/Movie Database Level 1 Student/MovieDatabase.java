import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

public class MovieDatabase extends World
{
    
    // Start of movie information.
    // The following would be better done in files, but is placed here to stay within
    // the APCSA subset. This does show the concept of parallel arrays.
    
    private String [] titles = {"Spider-Man, Into the Spider-Verse", "Spirited Away", "The Lion King", "Grave of the Fireflies", "Your Name.", "Coco", "WALL-E", "Princess Mononoke", "Up", "Toy Story 3", "How to Train Your Dragon" };
    private int [] years = { 2018, 2001, 1994, 1988, 2016, 2017, 2008, 1997, 2009, 2010, 1999 };
    private String [] descriptions = { "Teen Miles Morales becomes Spider-Man of his reality, crossing his path with five counterparts from other dimensions to stop a threat for all realities.",
            "During her family's move to the suburbs, a sullen 10-year-old girl wanders into a world ruled by gods, witches, and spirits, and where humans are changed into beasts.",
            "A Lion cub crown prince is tricked by a treacherous uncle into thinking he caused his father's death and flees into exile in despair, only to learn in adulthood his identity and his responsibilities.",
            "A young boy and his little sister struggle to survive in Japan during World War II.",
            "Two strangers find themselves linked in a bizarre way. When a connection forms, will distance be the only thing to keep them apart?",
            "Aspiring musician Miguel, confronted with his family's ancestral ban on music, enters the Land of the Dead to find his great-great-grandfather, a legendary singer.",
            "In the distant future, a small waste-collecting robot inadvertently embarks on a space journey that will ultimately decide the fate of mankind.",
            "On a journey to find the cure for a Tatarigami's curse, Ashitaka finds himself in the middle of a war between the forest gods and Tatara, a mining colony. In this quest he also meets San, the Mononoke Hime.",
            "Seventy-eight year old Carl Fredricksen travels to Paradise Falls in his home equipped with balloons, inadvertently taking a young stowaway.",
            "The toys are mistakenly delivered to a day-care center instead of the attic right before Andy leaves for college, and it's up to Woody to convince the other toys that they weren't abandoned and to return home.",
            "A hapless young Viking who aspires to hunt dragons becomes the unlikely friend of a young dragon himself, and learns there may be more to the creatures than he assumed."};
    private int [] numVotes = { 135933, 545575, 817960, 191136, 125602, 260890, 890434, 288391, 830246, 669582, 0};
    private int [] totalScores = {1169023, 4691945, 6952660, 1624656, 1055056, 2191476, 7479645, 2422484, 6891042, 5557530, 0};
    // End of movie information.
    
    
    private int moviesOnScreen = 4;
    private ArrayList<Movie> movies;
    private int currentIndex = 0;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MovieDatabase()
    {    
        super(1100, 600, 1); 

        buildMovies();
        displayMovies();
    }

    public void buildMovies()
    {
        movies = new ArrayList<>();

        for ( int i = 0; i < titles.length; i++ )
        {
            movies.add( new Movie( titles[i], years[i], descriptions[i], numVotes[i], totalScores[i] ));
        }

    }
    
    public void act()
    {
        if ( Greenfoot.isKeyDown( "left" ) )
        {
            currentIndex--;
            if ( currentIndex < 0 ) 
            {
                currentIndex = movies.size() - 1;
            }
            displayMovies();            
        }
        else if ( Greenfoot.isKeyDown( "right" ) )
        {
            currentIndex++;
            if ( currentIndex >= movies.size() )
            {
                currentIndex = 0;
            }
            displayMovies();
        }
        
    }
    
    public void displayMovies()
    {
        //clear the screen
        removeObjects( getObjects( null ) );
        
        
        int distance = getWidth() / ( moviesOnScreen + 1 );
        
        
        addObject( new AddButton(), getWidth() - distance / 3, getHeight() / 3 );
        
        for ( int i = 0; i < moviesOnScreen && i < movies.size(); i++ )
        {
            Movie current = movies.get( (currentIndex + i) % movies.size() );
            addObject( new MovieIcon( current ), distance + i * distance, getHeight() / 3 );
            addObject(  new Minus( current ), distance + i * distance + 90, getHeight() / 3 - 135 );
        }
        Greenfoot.delay(10);
    }
    
    public void addMovie( String title, int year, String description )
    {
        Movie m = new Movie( title, year, description );
        movies.add( m );
        displayMovies();
    }
    
    public void removeMovie( Movie m )
    {
        movies.remove( m );
        displayMovies();
    }
        

}
