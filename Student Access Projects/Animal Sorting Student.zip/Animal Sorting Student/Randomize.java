import greenfoot.*;

public class Randomize extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed(this) )
        {
            MyWorld w = (MyWorld)getWorld();
            w.randomize();
        }
    }    
}
