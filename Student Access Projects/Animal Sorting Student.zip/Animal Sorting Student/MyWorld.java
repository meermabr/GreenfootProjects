import greenfoot.*;
import java.util.*;

public class MyWorld extends World
{
    private static final int Y_LINE = 650;    
    private List<Animal> animals;

    public MyWorld()
    {    
        super(1000, 800, 1); 
        buildAnimals();
        buildButtons();
    }

    public void selectionSort()
    {
        // Write a standard selection sort to be applied to the field 'animals'.
        // Write the helper method 'swap' and use it to do the swapping of animals in the list.
        
        
        
        
        
        
        
    }

    public void swap(int index1, int index2)
    {
        // Leave this line to visually see the swap. This swap does not change the list.
        visualSwap( index1, index2 );

        // The list itself still needs its indices swapped
        // Write the code to swap these the values in these two indices in the animal list.

        
        
        
        
        
        
    }

    public void insertionSort()
    {
        // Write a standard insertion sort to be applied to the field 'animals'.
        // The visual movements are tricky, so visualLineUp() is provided to auto display
        // the final results of your sort, but if you want to attempt showing each
        // individual movement...
        
        // To add the visual movement aspect in, follow these steps:
        // a) Use the pull helper method when you begin a new index to insert.
        // b) Use the slide helper method on any index that needs to be pulled to the right,
        //    you will need to keep track of what X coordinate the animal should slide to
        // c) Use the slide helper method to pull the current inserting animal down to the right X
        // d) Use the pull helper method on the index that your inserting animal ended at
        
        
        
        
        
        
        
        // This line of code will display all animals in the order the list currently has for them
        visualLineUp();
    }

    
    public void randomize()
    {
        // Write the code that will randomize each Animal in the list.
        // The implementation of this code is up to you - but there are pitfalls if a bad
        // shuffling algorithm is used. Try an internet search for 1999 poker shuffling algorithm
        // to see an example of what could happen if a bad shuffle is used.
        
        
        
        
        
        
        
        
        
        
        // This line of code will display all animals in the order the list currently has for them
        visualLineUp();
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*****************        Helper Methods Below      *******************/
    /***************** These do not need to be modified *******************/
    
    
    
    
    
    /**
     * Builds the ArrayList of Animals and places each on the screen.
     * Uses one each of the Animal images.
     */
    private void buildAnimals()
    {
        animals = new ArrayList<>();

        for ( int i = 0; i < Animal.NUM_ANIMALS; i++ )
        {
            animals.add( new Animal( i ) );

            Animal a = animals.get( i );

            addObject( a, 0, Y_LINE - a.getImage().getHeight() / 2);
        }

        randomize();
    }

    /**
     * Places the insertion and selection sort buttons.
     */
    private void buildButtons()
    {
        addObject( new InsertionSort(), getWidth() * 3 / 4, 40 );
        addObject( new SelectionSort(), getWidth() * 2 / 4, 40 );
        addObject( new Randomize(), getWidth() / 4, 40 );
    }

    /**
     * Lines up all animals in the List in current index order.
     * The animal in the first index will be farther left
     * and the animal in the last index will be farthest right.
     * This has no delay and will quickly show the lineup.
     */
    private void visualLineUp()
    {
        int gap = getWidth() / animals.size();
        for ( int x = 0; x < animals.size(); x++ )
        {
            Animal a = animals.get( x );
            a.setLocation( x * gap + gap / 2, a.getY() );
        }
    }

    /**
     * Swaps two animals in the line at given indices.
     * The List is unchanged itself, only the physical
     * locations on the screen are modified.
     * 
     * This takes time to do. Alternately visualLineUp
     * may be used to instantly view the current order
     * of the List.
     * 
     * @param index1 The first index to be swapped.
     * @param index2 The second index to be swapped.
     */
    private void visualSwap( int index1, int index2 )
    {
        if ( index1 == index2 )
        {
            pull( index1 );
            pull( index1 );
            return;
        }

        pull( index1 );
        pull( index2 );

        slide2( index1, index2 );

        pull( index1 );
        pull( index2 );

    }

    /**
     * Visually pulls one animal either out of the line up or back into the line.
     * 
     * @param index The index of the animal to be pulled out or pushed back in.
     */
    private void pull( int index )
    {
        Animal a = animals.get( index );

        int dy = 4;
        if ( a.getY() > Y_LINE - a.getImage().getHeight() / 2 )
        {
            dy = -4;
        }

        for ( int y = 0; y < 25; y++ )
        {
            a.setLocation( a.getX(), a.getY() + dy );
            Greenfoot.delay( 1 );
        } 
    }

    /**
     * Visually slides one animal to a given X coordinate.
     * 
     * @param index The index of the animal to be moved.
     * @param xDestination The x coordinate of where the animal should be move to.
     */
    
    private void slide(int index, int xDestination)
    {
        Animal a = animals.get( index );
        int moveAmount = Math.abs( a.getX() - xDestination );

        int moveDistance = 5;
        if ( a.getX() > xDestination )
        {
            moveDistance = -5;
        }

        for ( int x = 0; x < moveAmount; x += Math.abs(moveDistance) )
        {
            a.move( moveDistance );
            Greenfoot.delay( 1 );
        }
    }

    /**
     * Visually slides two different animals so they end at each other's X coordinates
     * 
     * @param index1 The index of the first animal to be moved.
     * @param index2 The index of the second animal to be moved.
     */
    private void slide2( int index1, int index2 )
    {
        Animal a = animals.get( index1 );
        Animal b = animals.get( index2 );

        int moveAmount = Math.abs( a.getX() - b.getX() );

        int moveDistance = 5;
        if ( a.getX() > b.getX() )
        {
            moveDistance = -5;
        }

        for ( int x = 0; x < moveAmount; x += Math.abs(moveDistance) )
        {
            a.move( moveDistance );
            b.move( -moveDistance );
            Greenfoot.delay( 1 );
        }
    }

}
