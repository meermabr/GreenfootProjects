import greenfoot.*; 
public class InsertionSort extends Actor
{
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {   
            MyWorld w = (MyWorld)getWorld();
            w.insertionSort();
        }
    }    
}
