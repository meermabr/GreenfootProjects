import greenfoot.*; 

public class MyWorld extends World
{
    
    
    public MyWorld()
    {   
        super(1136, 936, 1); 
    }
}
