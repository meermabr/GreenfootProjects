import greenfoot.*;

/**
 * A class which stores a background image and provides methods which may modify it.
 */
public class Canvas extends PixelWorld
{
    //Feel free to change the images!
    private static String alternate = "Birds on a Line.png";
    private static String filename = "City Dancer.png";

    private static final GreenfootImage original = new GreenfootImage( filename );
    
    
    private int oldX, oldY; // Used for the drawing pen only. Keeps track of the last location of the mouse.

    /**
     * Constructor for objects of class Canvas, sets background to the default original picture.
     */
    public Canvas()
    {    
        super( original.getWidth(), original.getHeight(), 1 );
        reset();
        showText("Type a letter from a to z, the numbers 1 or 2, space, or enter for different effects", getWidth()/2, 30);
        
    }

    /**
     * Draw the original file back onto the background.
     */
    public void reset()
    {
        setBackground( filename );
    }

    /**
     * Purely a demonstration of doing some odd math on colors.
     * This keeps the old red of each pixel while using a 0-255 for
     * both green and blue based on the current row / column of a pixel.
     */
    public void weirdGradientDemo()
    {
        Color [][] pixels = getPixels();

        for ( int r = 0; r < pixels.length; r++ )
        {
            for ( int c = 0; c < pixels[r].length; c++ )
            {
                Color current = pixels[r][c];
                pixels[r][c] = new Color(  current.getRed(), r % 256, c % 256 );
            }
        }

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen turns into a randomly generated Color.
     */
    public void randomizeAllPixels()
    {
        Color [][] pixels = getPixels();


        
        setBackground( pixels );
    }

    /**
     * Every pixel on the screen turns into the same randomly generated Color.
     */
    public void randomizeSolid()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }

    /**
     * Every row on the screen gets one solid randomized color.
     */
    public void randomizeRows()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }

    /**
     * Every column on the screen gets one solid randomized color.
     */
    public void randomizeColumns()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen becomes slightly brighter than it was before.
     */
    public void brighter()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }  

    /**
     * Every pixel on the screen becomes slightly darker than it was before.
     */
    public void darker()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen becomes the inverted color of what it was before.
     * Example: (0,0,0) becomes (255,255,255)
     * Example: (1,100, 50) becomes ( 254, 155, 205)
     */
    public void invert()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old green and blue value but gets
     * an inverted amount of red value.
     * Example: (50, 30, 70) becomes (205, 30, 70)
     */
    public void invertRed()
    {
        Color [][] pixels = getPixels();

        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old red and blue value but gets
     * an inverted amount of green value.
     * Example: (50, 30, 70) becomes (50, 225, 70)
     */
    public void invertGreen()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old red and green value but gets
     * an inverted amount of blue value.
     * Example: (50, 30, 70) becomes (50, 30, 185)
     */
    public void invertBlue()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen becomes the closest gray equivalent pixel.
     * A gray value is the average of the old red, green, and blue values,
     * then replace the red, green, and blue values all with the calculated gray value.
     */
    public void grayScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );
    }

    /**
     * Every pixel on the screen keeps its old red and loses all of its green and blue.
     * Example: (50, 30, 70) becomes (50, 0, 0)
     */
    public void redScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its original red value, but changes
     * the green and blue value to the average of the red, green, and blue values.
     */
    public void redGrayScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its old red and loses all of its green and blue.
     * Example: (50, 30, 70) becomes (0, 30, 0)
     */
    public void greenScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its original green value, but changes
     * the red and blue value to the average of the red, green, and blue values.
     */
    public void greenGrayScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its old red and loses all of its green and blue.
     * Example: (50, 30, 70) becomes (0, 0, 70)
     */
    public void blueScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * Every pixel on the screen keeps its original blue value, but changes
     * the red and green value to the average of the red, green, and blue values.
     */
    public void blueGrayScale()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * The top half of the picture is duplicated, upside down, on the bottom of the picture.
     * The entire row 0 is thus placed in the final row.
     */
    public void mirrorTopToBottom()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    } 

    /**
     * The bottom half of the picture is duplicated, upside down, on the top of the picture.
     * The entire final row is thus placed in the first row.
     */
    public void mirrorBottomToTop()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }  

    /**
     * The left half of the picture is duplicated, in reverse, on the right half of the picture.
     * The entire column 0 is thus placed in the final column.
     */
    public void mirrorLeftToRight()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }    

    /**
     * The right half of the picture is duplicated, in reverse, on the left half of the picture.
     * The entire final column is thus placed in the first column.
     */
    public void mirrorRightToLeft()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }  

    /**
     * The entire image is flipped, with column 0 and the final column swapping locations.
     */
    public void flipHorizontal()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * The entire image is flipped, with row 0 and the final row swapping locations.
     */
    public void flipVertical()
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }

    /**
     * Compares every pair of pixels (a left pixel to a right) and determines
     * if the 'distance' between the two pairs of pixels is smaller than
     * the given threshold. If so, the pixel is set to white, if not the left
     * pixel is set to black.
     */
    public void detectEdges(int threshold)
    {
        Color [][] pixels = getPixels();

        
        

        setBackground( pixels );

    }    

    /**
     * Helper method which determines the 3-dimensional distance two colors
     * would be on a color cube.
     */
    private double colorDistance( Color a, Color b )
    {
        //This is an incorrect return. You need to calculate the distance
        //between the (r,g,b) values of Color a and Color b
        return 0;
    }    

    /**
     * Challenge: Given a 'strength', average the blocks of pixels of radius 'strength'
     * and make each pixel in the box equal the same value.
     */
    public void pixelate( int strength )
    {
        Color [][] pixels = getPixels();

        
        
        

        setBackground( pixels );

    }    

    /**
     * Hides the alternate imagefile defined in the fields.
     */
    public void hideImage()
    {
        hideImage( alternate );
    }

    /**
     * Hides a second image into the current background.
     * @param A filename which has a picture with the same size as the current background.
     */
    public void hideImage( String fileToHide )
    {
        Color [][] pixels = getPixels();

        GreenfootImage img = new GreenfootImage( fileToHide );
        Color [][] pixels2 = getPixels( img );

        
        
        
        

        setBackground( pixels );

    }

    /**
     * Flips each bit for the red/green/blue values.
     * If the red value is written ABCD EFGH in binary, then the flipped
     * red would be EFGH ABCD.
     */
    public void bitExchange()
    {        
        Color [][] pixels = getPixels();        

        
    
    
        setBackground( pixels );

    } 

    /**
     * Get the swapped equivalent of a Byte, in integer format.
     * @param An integer that will have its last 8 bits exchanged (often a Color value).
     * @return An integer with the last 4 bits exchanged with the second to last 4 bits
     */
    private int swapBits( int number )
    {
        // Grab the last 4 bits then bitshift them left 4 bits
        // Grab the second last 4 bits then bitshift them right 4 bits
        // Returns the combined two bitshifted numbers together using a bitwise or
        
        return 0; //This is incorrect, just a placeholder.
    }

    private int hideBits( int num1, int num2 )
    {
        // Grab the second to last 4 bits only
        // Grab the second to last 4 bits, bitshift them right 4
        // Returns the combined two numbers together using a bitwise or
        
        return 0; //This is incorrect, just a placeholder.
    }

    
    /**
     * If the mouse is currently on the screen and the mouse is being dragged then
     * this method will draw a line between the last location of the mouse and
     * the current location of the mouse. 
     * Postcondition: the oldX and oldY values need to be updated to the current
     * location of the mouse for the next time draw is called.
     */
    public void draw()
    {
        
    }
    
    
    // Demo Drawing Pen
    public void act()
    {
        draw();
        if ( Greenfoot.isKeyDown( "space" ) )
        {
            swapImage();
            Greenfoot.delay( 30 );
        }

        checkKeys();
    }

    public void swapImage()
    {
        String temp = filename;
        filename = alternate;
        alternate = temp;
        reset();        
    }

    public void checkKeys()
    {
        if ( Greenfoot.isKeyDown( "a" ) )
        {
            reset();
            this.weirdGradientDemo();
        }
        if ( Greenfoot.isKeyDown( "b" ) )
        {
            reset();
            this.randomizeAllPixels();
        }
        if ( Greenfoot.isKeyDown( "c" ) )
        {
            reset();
            this.randomizeSolid();
        }
        if ( Greenfoot.isKeyDown( "d" ) )
        {
            reset();
            this.randomizeRows();
        }
        if ( Greenfoot.isKeyDown( "e" ) )
        {
            reset();
            this.randomizeColumns();
        }
        if ( Greenfoot.isKeyDown( "f" ) )
        {
            this.brighter();
        }
        if ( Greenfoot.isKeyDown( "g" ) )
        {
            this.darker();
        }
        if ( Greenfoot.isKeyDown( "h" ) )
        {
            reset();
            this.invert();
        }
        if ( Greenfoot.isKeyDown( "i" ) )
        {
            reset();
            this.invertRed();
        }
        if ( Greenfoot.isKeyDown( "j" ) )
        {
            reset();
            this.invertGreen();
        }
        if ( Greenfoot.isKeyDown( "k" ) )
        {
            reset();
            this.invertBlue();
        }
        if ( Greenfoot.isKeyDown( "l" ) )
        {
            reset();
            this.grayScale();
        }
        if ( Greenfoot.isKeyDown( "m" ) )
        {
            reset();
            this.redScale();
        }
        if ( Greenfoot.isKeyDown( "n" ) )
        {
            reset();
            this.redGrayScale();
        }
        if ( Greenfoot.isKeyDown( "o" ) )
        {
            reset();
            this.greenScale();
        }
        if ( Greenfoot.isKeyDown( "p" ) )
        {
            reset();
            this.greenGrayScale();
        }
        if ( Greenfoot.isKeyDown( "q" ) )
        {
            reset();
            this.blueScale();
        }
        if ( Greenfoot.isKeyDown( "r" ) )
        {
            reset();
            this.blueGrayScale();
        }
        if ( Greenfoot.isKeyDown( "s" ) )
        {
            reset();
            this.mirrorTopToBottom();
        }
        if ( Greenfoot.isKeyDown( "t" ) )
        {
            reset();
            this.mirrorBottomToTop();
        }
        if ( Greenfoot.isKeyDown( "u" ) )
        {
            reset();
            this.mirrorLeftToRight();
        }
        if ( Greenfoot.isKeyDown( "v" ) )
        {
            reset();
            this.mirrorRightToLeft();
        }
        if ( Greenfoot.isKeyDown( "w" ) )
        {
            reset();
            this.flipHorizontal();
        }
        if ( Greenfoot.isKeyDown( "x" ) )
        {
            reset();
            this.flipVertical();
        }
        if ( Greenfoot.isKeyDown( "y" ) )
        {
            reset();
            String answer = Greenfoot.ask("What threshold for edges? (An integer bigger than 0)");
            this.detectEdges( Integer.valueOf(answer) );
        }
        if ( Greenfoot.isKeyDown( "z" ) )
        {
            reset();
            String answer = Greenfoot.ask("How strong of a pixelation? (An integer bigger than 0)");
            this.pixelate( Integer.valueOf(answer) );
        }
        if ( Greenfoot.isKeyDown( "enter" ) )
        {
            reset();
            this.swapImage();
            Greenfoot.delay( 30 );
        }
        if ( Greenfoot.isKeyDown( "1" ) )
        {
            this.hideImage();
        }
        if ( Greenfoot.isKeyDown( "2" ) )
        {
            this.bitExchange();
        }
    }

}
