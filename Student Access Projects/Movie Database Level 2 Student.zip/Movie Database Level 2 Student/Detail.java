import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Detail extends Actor
{

    public Detail( Movie m  )
    {
        GreenfootImage img = new GreenfootImage( 200, 200 );
        img.setColor( Color.BLACK );
        img.fill();
        
        img.setColor( Color.WHITE );
        img.drawRect( 0, 0, img.getWidth() - 1, img.getHeight() - 1);
        
        
        img.drawString( m.getTitle(), 10, 20 );
        img.drawString( "(" + m.getYear() + ")", 10, 40 );
        double rounded = (int)(m.getRating() * 10 + 0.5) / 10.0;
        if ( rounded < 1 || rounded > 10 ) 
        {
            img.drawString( "Rating: Not Yet Rated", 10, 60 );
        }
        else
        {
            img.drawString( "Rating: " + rounded, 10, 60 );
        }
        
        img.drawString( getFormattedDescription( m.getDescription(), 32 ), 10, 80 );
        setImage( img );
    }

    
    
    private String getFormattedDescription( String description, int lineLength )
    {            
        String [] words = description.split( " " );
        String ans = "";
        
        int currentLength = 0;
        
        for ( int i = 0; i < words.length; i++ )
        {
            if ( currentLength + words[i].length() > lineLength )
            {
                ans += "\n";
                currentLength = 0;
            }
            ans += words[i] + " ";
            currentLength += words[i].length() + 1;
        }
        
        return ans;
    }
}
