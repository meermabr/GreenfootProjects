import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Arrow extends Actor
{
    private boolean isLeft;
    private String myKey;

    public Arrow( boolean isLeft )
    {
        if ( isLeft )
        {
            myKey = "left";
            setImage( "left.png" );
        }
        else
        {
            myKey = "right";
            setImage( "right.png" );
        }
            
        this.isLeft = isLeft;
    }
    
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) || Greenfoot.isKeyDown( myKey ) )
        {
            MovieDatabase w = (MovieDatabase)getWorld();
            w.cycleMovie( isLeft );
        }
    }    
}
