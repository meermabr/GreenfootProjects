import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Minus here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Minus extends Actor
{
    private Movie movie;
    
    public Minus( Movie movie )
    {
        this.movie = movie;
    }
    
    
    public void act() 
    {
        if ( Greenfoot.mousePressed( this ) )
        {
            String answer = Greenfoot.ask( "Do you really wish to remove " + movie.getTitle() + "? (yes or no)" );
            if ( answer.equals( "yes" ) )
            {
                MovieDatabase w = (MovieDatabase)getWorld();
                w.removeMovie( movie );
            }            
        }
    
    }    
}
