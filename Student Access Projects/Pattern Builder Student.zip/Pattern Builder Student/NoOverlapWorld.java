import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NoOverlapWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NoOverlapWorld extends World
{

    /**
     * Constructor for objects of class NoOverlapWorld.
     * 
     */
    public NoOverlapWorld(int width, int height, int cellSize )
    {    
        super(width, height, cellSize); 
        drawGrid();
    }
    
    public void addObject( Actor a, int x, int y )
    {
        if ( getObjectsAt(x, y, null).isEmpty() )
        {
            super.addObject( a, x, y  );
        }
        else
        {
            showText( "Oh no! Overlapped objects at (" + x + ", " + y + ")", getWidth() / 2, getHeight() / 2 );            
            super.addObject( a, x, y  );
            Greenfoot.stop();
        }
    }
    
    public void drawGrid()
    {
        GreenfootImage bg = getBackground();
        bg.setColor( Color.LIGHT_GRAY );
        for ( int x = 1; x < getWidth(); x++ )
        {
            bg.drawLine( x * getCellSize(), 0, x * getCellSize(), getHeight() * getCellSize() );
        }
        for ( int y = 1; y < getHeight(); y++ )
        {
            bg.drawLine( 0, y * getCellSize(), getWidth() * getCellSize(), y * getCellSize() );
        }
        
                
        
    }
    
}
