import greenfoot.*;

public class MyWorld extends NoOverlapWorld
{

    private static final int WIDTH = 57;
    private static final int HEIGHT = 45;

    public MyWorld()
    {    
        // Create a new world with 20x15 cells with a cell size of 60x60 pixels.
        super(WIDTH, HEIGHT, 20); 
    }

    // Removes all objects from the screen
    public void removeAll()
    {
        removeObjects( getObjects(null) );
    }

    public void allMiddle()
    {
        
        
    }

    public void border()
    {
        
        
    }

    public void checkered()
    {
        
        
    } 

    public void diagonals()
    {
        
        
    }

    public void equator()
    {
        
        
    }

    public void fibonacci()
    {
        
        
    }
  
    public void geometricSeries()
    {
        
        
    }  
    
    public void hemisphereLeft()
    {
        
        
    }
        
    public void hemisphereRight()
    {
        
        
    }
    
    public void hemisphereTop()
    {
        
        
    }
    
    public void hemisphereBottom()
    {
        
        
    }
        
    public void isosclesRightA()
    {
        
        
    }
    
    public void isosclesRightB()
    {
        
        
    }    
            
    public void isosclesRightC()
    {
        
        
    }
    
    public void isosclesRightD()
    {
        
        
    }      
    
    public void jaggedSteps()
    {
        
        
    }
    
    
    // Allows the keyboard to use each of the above methods
    public void act()
    {
        if ( Greenfoot.isKeyDown( "a" ) )
        {
            this.allMiddle();
        }
        if ( Greenfoot.isKeyDown( "b" ) )
        {
            this.border();
        }
        if ( Greenfoot.isKeyDown( "c" ) )
        {
            this.checkered();
        }
        if ( Greenfoot.isKeyDown( "d" ) )
        {
            this.diagonals();
        }
        if ( Greenfoot.isKeyDown( "e" ) )
        {
            this.equator();
        }
        if ( Greenfoot.isKeyDown( "f" ) )
        {
            this.fibonacci();
        }
        if ( Greenfoot.isKeyDown( "g" ) )
        {
            this.geometricSeries();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "1" ) )
        {
            this.hemisphereLeft();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "2" ) )
        {
            this.hemisphereRight();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "3" ) )
        {
            this.hemisphereTop();
        }
        if ( Greenfoot.isKeyDown( "h" ) && Greenfoot.isKeyDown( "4" ) )
        {
            this.hemisphereBottom();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "1" ))
        {
            this.isosclesRightA();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "2" ))
        {
            this.isosclesRightB();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "3" ))
        {
            this.isosclesRightC();
        }
        if ( Greenfoot.isKeyDown( "i" ) && Greenfoot.isKeyDown( "4" ))
        {
            this.isosclesRightD();
        }
        if ( Greenfoot.isKeyDown( "j" ) )
        {
            this.jaggedSteps();
        }
    }
    
}