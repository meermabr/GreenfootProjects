import greenfoot.*;  

public class CryptoWorld extends World
{
    private static final int FONT_SIZE = 32;
    private String phrase = "password";
    private Label word;
    private Label shiftValue;
    private Label [] letterCounts;
    private Label [] numberCounts;
    private Label currentAlphabet;
    private int amount = 0;

    public CryptoWorld()
    {    
        super(1024, 765, 1); 
        
        
        word = new Label( phrase, FONT_SIZE );
        shiftValue = new Label( amount, FONT_SIZE );
        currentAlphabet = new Label( "abcdefghijklmonpqrstuvwxyz", FONT_SIZE );
        
        letterCounts = new Label[26];
        numberCounts = new Label[10];
        for ( int i = 0; i < 13; i++ )
        {
            letterCounts[i] = new Label( (char)(i + 'A') + ": 0", FONT_SIZE );
            addObject( letterCounts[i], (i - 6) * FONT_SIZE*2 + getWidth() / 2, getHeight() / 6 * 3 );
        }
        for ( int i = 13; i < 26; i++ )
        {
            letterCounts[i] = new Label( (char)(i + 'A') + ": 0", FONT_SIZE );
            addObject( letterCounts[i], (i - 19) * FONT_SIZE*2 + getWidth() / 2, getHeight() / 6 * 3 + FONT_SIZE );
        }
        
        for ( int i = 0; i < 10; i++ )
        {
            numberCounts[i] = new Label( i + ": 0", FONT_SIZE );
            addObject( numberCounts[i], (i - 5) * FONT_SIZE*2 + getWidth() / 2, getHeight() / 6 * 3 + 2 * FONT_SIZE );
        }
        
        
        addObject( new Label( "Current String", 30), getWidth() / 2, getHeight() / 6 - FONT_SIZE );
        addObject( word, getWidth() / 2, getHeight() / 6 );
        addObject( new Label("Current Caesar Shift Amount", 30), getWidth() / 2, getHeight() / 6 * 2 - FONT_SIZE );
        addObject( shiftValue, getWidth() / 2, getHeight() / 6 * 2 );
        addObject( new Label( "Current Alphabet", 30), getWidth() / 2, getHeight() * 5 / 6 - FONT_SIZE );
        addObject( currentAlphabet, getWidth() / 2, getHeight() * 5 / 6 );
        
        
        update();
    }

    public void act()
    {
        if ( Greenfoot.isKeyDown( "up" ) )
        {
            updateAmount( 1 );
            update();
        }
        if ( Greenfoot.isKeyDown( "down" ) )
        {
            updateAmount( -1 );
            update();
        }

        if ( Greenfoot.isKeyDown( "enter" ) )
        {
            phrase = Greenfoot.ask("Enter a sentence to encrypt or decrypt:");
            phrase = phrase.toLowerCase();
            update();
        }

        if ( Greenfoot.isKeyDown( "left" ) )
        {
            phrase = Cryptography.shift(phrase, -amount);
            update();
        }       

        if ( Greenfoot.isKeyDown( "right" ) )
        {
            phrase = Cryptography.shift(phrase, amount);
            update();
        }
        
        if ( Greenfoot.isKeyDown( "space" ) )
        {
            String alphabet = Greenfoot.ask( "Enter the replacement alphabet you wish to use.\nEach letter should be used exactly once otherwise nothing will occur." );
            String temp = Cryptography.substitution(phrase, alphabet);
            if ( !temp.equals( phrase ) )
            {
                currentAlphabet.setValue( alphabet );
                phrase = temp;
                update();
            }
        }
    }

 

    public void updateAmount( int num )
    {
        amount += num;
        if ( amount < 0 )
        {
            amount = 25;
        }
        else if ( amount > 25 )
        {
            amount = 0;
        }
        shiftValue.setValue(amount);
    }

    public void update()
    {
        word.setValue( phrase );
        
        int [] letterValues = Cryptography.letterCount(phrase);
        int [] numberValues = Cryptography.numberCount(phrase);
        for ( int i = 0; i < letterCounts.length; i++ )
        {
            letterCounts[i].setValue((char)(i + 'A') + ": " + letterValues[i] );
        }
        for ( int i = 0; i < numberCounts.length; i++ )
        {
            numberCounts[i].setValue(i + ": " + numberValues[i] );
        }
        
        Greenfoot.delay( 5 );
    }

}
