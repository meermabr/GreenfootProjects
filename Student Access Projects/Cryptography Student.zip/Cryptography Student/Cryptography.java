/**
 * Utility class that performs actions on Strings useful for cryptography practice.
 * Each method will automatically remove all non-letters and turn all letters lowercase.
 */

public class Cryptography  
{
    /**
     * Returns a new String with only the alphabetic and numeric
     * values remaining. Converts all alphabetic symbols to lowercase.
     * 
     * @param input The original String to be converted
     * @return A new String with only alphanumeric values remaining and all lowercase
     */
    public static String parseNonAlphaNumerics( String input )
    {
        return "";
    }

    /**
     * Applies the Caesar shift algorithm to a given String.
     * All alphabetic letters are shifted right in the alphabet
     * by the given number. All non-alphabetic letters do not
     * change.
     * 
     * @param input The original String to be Caesar shifted
     * @param num A number between -26 and 26, representing how many spots in the alphabet to shift
     * @return The Caesar shifted String with non-alphabetic characters untouched
     */
    public static String shift( String input, int num )
    {
        input = parseNonAlphaNumerics( input );
        
        return "";
    }

    /**
     * Calculates how many of each letter in the alphabet a given String has.
     * 
     * @param input The original String to count, all alphabetic letters should be lowercase
     * @return A 26 slotted array with slot 0 containing the number of As in the input,
     * slot 1 containing the number of Bs, and so on.
     */
    public static int [] letterCount( String input )
    {
        input = parseNonAlphaNumerics( input );

        return new int[26];
    }

    /**
     * Calculates how many of each numberic digit the given String has.
     * 
     * @param input The original String to count.
     * @return A 10 slotted array, with slot 0 containing the number of 0s in the String,
     * slot 1 containing the number of 1s, and so on.
     */
    public static int [] numberCount( String input )
    {
        input = parseNonAlphaNumerics( input );

        return new int[10];
    }

    /**
     * Applies a substitution cipher to a given String input. 
     * Each letter in the original String will be converted to the corresponding 
     * location in the supplied alphabet. 
     * 
     * For instance, if the replacementAlphabet was "qwertyuiopasdfghjklzxcvbnm"
     * then any 'a's in the original input would turn into 'q's, any 'b's would turn
     * into 'w's, and so on.
     * 
     * @param input The original String to have the cipher applied to.
     * @param replacementAlphabet A 26 character long String using each of the 
     * alphabetic symbols exactly once
     * 
     */
    public static String substitution( String input, String replacementAlphabet )
    {

        input = parseNonAlphaNumerics( input );

        return "";
    }

    /**
     * Returns true or false if a given char is a lowercase alphabetic letter.
     * @param c The character to be checked.
     * @return true if c is a lowercase alphabetic char ('a' - 'z')
     */
    public static boolean isLetter(char c)
    {
        return true;
    }

    /**
     * Returns true or false if a given char is a numeric digit.
     * @param c The character to be checked.
     * @return true if c is a numeric char ('0' - '9')
     */
    public static boolean isNumber(char c)
    {
        return true;
    }    
}
